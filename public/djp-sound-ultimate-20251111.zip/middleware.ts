import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Rate limiting très simple (mémoire, non persistant). Convient pour POC/dev.
// Pour prod, utilisez un KV/Redis (Cloudflare, Upstash, etc.).
const WINDOW_MS = 60 * 1000; // 1 minute
const MAX_REQ = 60; // 60 requêtes/min par IP
const ipToTimestamps = new Map<string, number[]>();

function getClientIp(req: NextRequest): string {
  // Essayez d'abord les entêtes standards via proxy/CDN
  const viaHeader =
    req.headers.get('x-forwarded-for') ||
    req.headers.get('x-real-ip') ||
    '';
  if (viaHeader) {
    // x-forwarded-for: "client, proxy1, proxy2"
    const first = viaHeader.split(',')[0].trim();
    if (first) return first;
  }
  // Fallback
  return req.ip ?? '0.0.0.0';
}

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  // Appliquer la limite uniquement aux endpoints API
  if (pathname.startsWith('/api')) {
    const ip = getClientIp(req);
    const now = Date.now();
    const windowStart = now - WINDOW_MS;
    const arr = ipToTimestamps.get(ip) || [];
    // Purge anciennes timestamps
    const recent = arr.filter(ts => ts > windowStart);
    if (recent.length >= MAX_REQ) {
      return new NextResponse('Too Many Requests', { status: 429 });
    }
    recent.push(now);
    ipToTimestamps.set(ip, recent);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ['/api/:path*'],
};


