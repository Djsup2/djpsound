// Import du composant principal depuis la racine
import UltimateDjpSound from '../djp-sound-ultimate';

export default UltimateDjpSound;

