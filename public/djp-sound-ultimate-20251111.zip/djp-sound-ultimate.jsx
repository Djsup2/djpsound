import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useRouter } from 'next/router';
import { ethers } from 'ethers';
import { Connection } from '@solana/web3.js';
import { motion, AnimatePresence, LazyMotion, domAnimation } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import { Howl } from 'howler';
import { toast, ToastContainer } from 'react-toastify';
import {
  Disc, Upload, Wallet, X, Headphones, Home, Album, Play, Pause, Settings
} from 'lucide-react';
import 'react-toastify/dist/ReactToastify.css';

// Configuration ultime
const CONFIG = {
  appName: "DJP Sound Revolution",
  creatorAddress: "4wj3rnh3y318TR4HLV77Vdu76Ag4uwPJGNeYiTEv3Xd8", // Solana public key du créateur
  managerAddress: "0x41e1f657a959cdbb09d803d59186dacab0a438ce", // Ethereum address du gestionnaire
  security: {
    maxFileSizeBytes: 50 * 1024 * 1024, // 50MB
    maxImagePreviewBytes: 2 * 1024 * 1024, // 2MB
    maxShowcaseItems: 50
  },
  tokens: {
    premium: "GmSP3SJ6bTso7HA3oH53sp2hRemv82igNd1RUe12pump",
    vip: "7gTgvQaW4Zmz1yQdC6QnJKJHPdciNwFmBVK792tUpump"
  },
  apis: {
    birdeyeKey: process.env.NEXT_PUBLIC_BIRDEYE_API_KEY,
    solscanBase: "https://public-api.solscan.io"
  },
  showcases: [
    { id: 'vitrine-principale', label: 'Vitrine principale' },
    { id: 'nouveautes', label: 'Nouveautés' },
    { id: 'exclusifs', label: 'Exclusifs' }
  ],
  prices: {
    premium: 1.00, // 1€
    vip: 5.00      // 5€
  },
  contracts: {
    ethereum: {
      address: "0x742d35Cc6634C0532925a3b844Bc454e4438f44e",
      abi: [
        "function balanceOf(address owner, bytes32 tokenHash) view returns (uint256)",
        "function purchaseToken(bytes32 tokenHash, uint256 amount) payable"
      ]
    }
  },
  rpc: {
    ethereum: process.env.NEXT_PUBLIC_ETH_RPC,
    solana: "https://api.mainnet-beta.solana.com"
  }
};

// Initialisation audio globale
const audioManager = {
  player: null,
  init(src) {
    this.player = new Howl({
      src: [src],
      html5: true,
      preload: 'metadata',
      volume: 0.7
    });
  }
};

export default function UltimateDjpSound() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState(router.pathname.slice(1) || 'home');
  const [web3, setWeb3] = useState(null);
  const [solana, setSolana] = useState(null);
  const [account, setAccount] = useState(null);
  const [audioPreview, setAudioPreview] = useState(null);
  const [visitCount, setVisitCount] = useState(0);
  const [holdersCount, setHoldersCount] = useState(null);
  const [holdersLoading, setHoldersLoading] = useState(false);
  const [showLegal, setShowLegal] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [customTokens, setCustomTokens] = useState([]);
  const [activeCreatorTokenId, setActiveCreatorTokenId] = useState(null);
  const isCreator = account?.chain === 'solana' && account?.address === CONFIG.creatorAddress;
  const isManager = account?.chain === 'ethereum' && account?.address?.toLowerCase() === CONFIG.managerAddress?.toLowerCase();
  const hasPrivilegedAccess = isCreator || isManager;

  // Préchargement stratégique
  useEffect(() => {
    const preloadAssets = async () => {
      // Préchargement des pages critiques
      router.prefetch('/upload');
      router.prefetch('/library');
      
      // Initialisation des connexions blockchain
      if (window.ethereum) {
        setWeb3(new ethers.providers.Web3Provider(window.ethereum));
      } else if (CONFIG.rpc.ethereum) {
        setWeb3(new ethers.providers.JsonRpcProvider(CONFIG.rpc.ethereum));
      }
      setSolana(new Connection(CONFIG.rpc.solana));
    };

    preloadAssets();
  }, []);

  // Charger tokens personnalisés et token actif
  useEffect(() => {
    try {
      const raw = localStorage.getItem('djp_tokens');
      const saved = raw ? JSON.parse(raw) : [];
      setCustomTokens(Array.isArray(saved) ? saved : []);
      const savedActive = localStorage.getItem('djp_active_token');
      setActiveCreatorTokenId(savedActive || null);
    } catch {
      setCustomTokens([]);
      setActiveCreatorTokenId(null);
    }
  }, []);

  const handleAddToken = useCallback((token) => {
    try {
      const next = [token, ...customTokens];
      setCustomTokens(next);
      localStorage.setItem('djp_tokens', JSON.stringify(next));
      toast.success('Token ajouté');
    } catch (e) {
      toast.error(`Impossible d'enregistrer le token: ${e.message}`);
    }
  }, [customTokens]);

  const handleRemoveToken = useCallback((id) => {
    const next = customTokens.filter(t => t.id !== id);
    setCustomTokens(next);
    localStorage.setItem('djp_tokens', JSON.stringify(next));
    if (activeCreatorTokenId === id) {
      setActiveCreatorTokenId(null);
      localStorage.removeItem('djp_active_token');
    }
  }, [customTokens, activeCreatorTokenId]);

  const handleSetActiveToken = useCallback((id) => {
    setActiveCreatorTokenId(id);
    if (id) localStorage.setItem('djp_active_token', id);
    else localStorage.removeItem('djp_active_token');
  }, []);

  // Compteur de visites (unique par jour, côté navigateur)
  useEffect(() => {
    try {
      const today = new Date();
      const ymd = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      const lastDay = localStorage.getItem('djp_visit_last_day');
      let total = parseInt(localStorage.getItem('djp_visit_total') || '0', 10);
      if (lastDay !== ymd) {
        total += 1;
        localStorage.setItem('djp_visit_last_day', ymd);
        localStorage.setItem('djp_visit_total', String(total));
      }
      setVisitCount(total);
    } catch {
      // ignorer erreurs de quota/privé
    }
  }, []);

  // Compteur de holders DJP (Solana) via API publique (Birdeye > Solscan > fallback)
  useEffect(() => {
    const fetchHolders = async () => {
      setHoldersLoading(true);
      // Résoudre le token actif: custom token choisi sinon token premium par défaut
      const active = customTokens.find(t => t.id === activeCreatorTokenId) || null;
      const isSolana = active ? active.chain === 'solana' : true;
      const mint = active?.address || CONFIG.tokens.premium;
      if (!isSolana) {
        // Non supporté pour Ethereum dans cette implémentation
        setHoldersCount(null);
        setHoldersLoading(false);
        return;
      }
      // 1) Birdeye
      if (CONFIG.apis.birdeyeKey) {
        try {
          const res = await fetch(`https://public-api.birdeye.so/public/token/holder_count?address=${mint}`, {
            headers: { 'X-API-KEY': CONFIG.apis.birdeyeKey }
          });
          if (res.ok) {
            const data = await res.json();
            if (data?.data?.holder) {
              setHoldersCount(data.data.holder);
              setHoldersLoading(false);
              return;
            }
          }
        } catch {
          // passe à Solscan
        }
      }
      // 2) Solscan fallback
      try {
        const res = await fetch(`${CONFIG.apis.solscanBase}/token/holders?tokenAddress=${mint}&limit=1&offset=0`);
        if (res.ok) {
          const data = await res.json();
          // Solscan renvoie potentiellement 'total' pour le nombre total
          if (typeof data?.total === 'number') {
            setHoldersCount(data.total);
            setHoldersLoading(false);
            return;
          }
        }
      } catch {
        // ignore
      }
      // 3) Fallback
      setHoldersCount(null);
      setHoldersLoading(false);
    };
    fetchHolders();
  }, [customTokens, activeCreatorTokenId]);

  // Gestion audio optimisée (memoized)
  const handleAudioPreview = useCallback((file) => {
    if (audioManager.player) {
      audioManager.player.unload();
    }
    const objectUrl = URL.createObjectURL(file);
    audioManager.init(objectUrl);
    setAudioPreview(objectUrl);
  }, []);

  // Connexion multi-chaîne (memoized)
  const connectWallet = useCallback(async (chain) => {
    try {
      if (chain === 'ethereum') {
        if (!window.ethereum) {
          toast.error(
            <div className="text-sm">
              <div className="font-semibold mb-1">MetaMask non détecté</div>
              <div>Veuillez installer l’extension MetaMask pour vous connecter à Ethereum.</div>
              <a
                href="https://metamask.io/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-cyan-400 underline mt-1 inline-block"
              >
                Installer MetaMask
              </a>
            </div>
          );
          return;
        }
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        setAccount({
          address: accounts[0],
          chain: 'ethereum'
        });
      } else {
        const phantom = window.solana;
        if (!phantom?.isPhantom) {
          toast.error(
            <div className="text-sm">
              <div className="font-semibold mb-1">Phantom non détecté</div>
              <div>Veuillez installer l’extension Phantom pour vous connecter à Solana.</div>
              <a
                href="https://phantom.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-cyan-400 underline mt-1 inline-block"
              >
                Installer Phantom
              </a>
            </div>
          );
          return;
        }
        if (phantom?.isPhantom) {
          await phantom.connect();
          setAccount({
            address: phantom.publicKey.toString(),
            chain: 'solana'
          });
        }
      }
    } catch (error) {
      toast.error(`Connexion impossible: ${error.message}`);
    }
  }, []);

  return (
    <LazyMotion features={domAnimation}>
      <div className="min-h-screen bg-gradient-to-br from-gray-950 to-gray-900 text-gray-100">
        {/* Navigation intelligente */}
        <SmartNavigation 
          activeTab={activeTab}
          account={account}
          visitCount={visitCount}
          holdersCount={holdersCount}
          holdersLoading={holdersLoading}
          onNavigate={useCallback((tab) => {
            setActiveTab(tab);
            router.push(tab === 'home' ? '/' : `/${tab}`);
          }, [router])}
          onConnectWallet={connectWallet}
          onDisconnect={useCallback(() => setAccount(null), [])}
        />
        
        {/* Contenu principal optimisé */}
        <main className="container mx-auto px-4 py-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              {activeTab === 'home' && <HomePage />}
              {activeTab === 'upload' && (
                <AccessGate isAllowed={hasPrivilegedAccess} reason="Fonctionnalité réservée au créateur ou au gestionnaire.">
                  <UploadFlow 
                    account={account}
                    onAudioPreview={handleAudioPreview}
                    audioPreview={audioPreview}
                  />
                </AccessGate>
              )}
              {activeTab === 'library' && <LibraryPage />}
              {activeTab === 'settings' && (
                <AccessGate isAllowed={hasPrivilegedAccess} reason="Page réservée au créateur ou au gestionnaire.">
                  <CreatorSettingsPage
                    tokens={customTokens}
                    activeTokenId={activeCreatorTokenId}
                    onAddToken={handleAddToken}
                    onRemoveToken={handleRemoveToken}
                    onSetActiveToken={handleSetActiveToken}
                  />
                </AccessGate>
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* Player audio global */}
        {audioPreview && (
          <GlobalAudioPlayer 
            src={audioPreview}
            onClose={() => {
              audioManager.player.unload();
              if (audioPreview) {
                URL.revokeObjectURL(audioPreview);
              }
              setAudioPreview(null);
            }}
          />
        )}

        <ToastContainer position="bottom-right" theme="dark" />
        
        {/* Mentions légales / Disclaimer */}
        <footer className="border-t border-gray-800 bg-gray-900/70">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between text-xs text-gray-400">
            <span>© {new Date().getFullYear()} {CONFIG.appName}</span>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowLegal(true)}
                className="text-cyan-400 hover:text-cyan-300 underline"
                aria-label="Ouvrir les mentions légales et clauses de non-responsabilité"
              >
                Mentions légales & clauses
              </button>
              <button
                onClick={() => setShowPrivacy(true)}
                className="text-cyan-400 hover:text-cyan-300 underline"
                aria-label="Ouvrir la politique de confidentialité"
              >
                Politique de confidentialité
              </button>
              <button
                onClick={() => setShowTerms(true)}
                className="text-cyan-400 hover:text-cyan-300 underline"
                aria-label="Ouvrir les conditions d’utilisation"
              >
                Conditions d’utilisation
              </button>
            </div>
          </div>
        </footer>

        {showLegal && <LegalModal onClose={() => setShowLegal(false)} />}
        {showPrivacy && <PrivacyModal onClose={() => setShowPrivacy(false)} />}
        {showTerms && <TermsModal onClose={() => setShowTerms(false)} />}
      </div>
    </LazyMotion>
  );
}

const SiteStats = React.memo(function SiteStats({ visitCount, holdersCount, holdersLoading }) {
  return (
    <div className="hidden md:flex items-center space-x-2 mr-3">
      <div className="text-xs px-2 py-1 rounded bg-gray-800 border border-gray-700 text-gray-300">
        Visites: <span className="font-semibold">{visitCount || 0}</span>
      </div>
      <div className="text-xs px-2 py-1 rounded bg-gray-800 border border-gray-700 text-gray-300">
        Holders DJP: <span className="font-semibold">{holdersLoading ? '...' : (holdersCount ?? 'N/A')}</span>
      </div>
    </div>
  );
});

function CreatorSettingsPage({ tokens, activeTokenId, onAddToken, onRemoveToken, onSetActiveToken }) {
  const [form, setForm] = useState({
    name: '',
    symbol: '',
    chain: 'solana',
    address: '',
    decimals: 9
  });

  const validate = () => {
    if (!form.name || !form.symbol || !form.address) return 'Champs requis manquants';
    if (!['solana', 'ethereum'].includes(form.chain)) return 'Chaîne invalide';
    if (form.chain === 'ethereum' && !/^0x[a-fA-F0-9]{40}$/.test(form.address)) return 'Adresse Ethereum invalide';
    if (form.chain === 'solana' && form.address.length < 32) return 'Adresse Solana invalide';
    return null;
  };

  const addToken = () => {
    const err = validate();
    if (err) {
      toast.error(err);
      return;
    }
    const id = `${form.chain}:${form.address}`;
    onAddToken({ id, ...form, createdAt: new Date().toISOString() });
    setForm({ name: '', symbol: '', chain: 'solana', address: '', decimals: 9 });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
        <div className="text-sm font-semibold text-gray-100 mb-3">Ajouter un token</div>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs text-gray-400 mb-1">Nom</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="w-full bg-gray-900 border border-gray-700 rounded p-2 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Symbole</label>
            <input value={form.symbol} onChange={(e) => setForm({ ...form, symbol: e.target.value })} className="w-full bg-gray-900 border border-gray-700 rounded p-2 text-sm" />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Chaîne</label>
            <select value={form.chain} onChange={(e) => setForm({ ...form, chain: e.target.value })} className="w-full bg-gray-900 border border-gray-700 rounded p-2 text-sm">
              <option value="solana">Solana</option>
              <option value="ethereum">Ethereum</option>
            </select>
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Adresse (mint/contrat)</label>
            <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value.trim() })} className="w-full bg-gray-900 border border-gray-700 rounded p-2 text-sm font-mono" />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Décimales</label>
            <input type="number" min={0} max={18} value={form.decimals} onChange={(e) => setForm({ ...form, decimals: parseInt(e.target.value || '0', 10) })} className="w-full bg-gray-900 border border-gray-700 rounded p-2 text-sm" />
          </div>
        </div>
        <div className="mt-3">
          <button onClick={addToken} className="px-3 py-2 text-sm bg-cyan-600 hover:bg-cyan-700 rounded-md text-white">Ajouter</button>
        </div>
      </div>

      <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
        <div className="text-sm font-semibold text-gray-100 mb-3">Tokens créateur</div>
        {tokens.length === 0 ? (
          <div className="text-xs text-gray-400">Aucun token ajouté pour l’instant.</div>
        ) : (
          <div className="space-y-2">
            {tokens.map(t => (
              <div key={t.id} className="flex items-center justify-between bg-gray-900/40 border border-gray-800 rounded p-2">
                <div className="text-xs">
                  <div className="text-gray-100 font-semibold">{t.name} ({t.symbol})</div>
                  <div className="text-gray-400">Chaîne: {t.chain} • Décimales: {t.decimals}</div>
                  <div className="text-gray-500 font-mono truncate">{t.address}</div>
                </div>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => onSetActiveToken(t.id)}
                    className={`px-2 py-1 text-xs rounded ${activeTokenId === t.id ? 'bg-green-700 text-white' : 'bg-gray-700 text-gray-200 hover:bg-gray-600'}`}
                  >
                    {activeTokenId === t.id ? 'Actif' : 'Activer'}
                  </button>
                  <button
                    onClick={() => onRemoveToken(t.id)}
                    className="px-2 py-1 text-xs rounded bg-red-800/70 text-red-100 hover:bg-red-700"
                  >
                    Supprimer
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function AccessGate({ isAllowed, reason, children }) {
  if (isAllowed) return children;
  return (
    <div className="max-w-3xl mx-auto">
      <div className="border border-amber-600 bg-amber-900/30 text-amber-200 rounded-lg p-6">
        <div className="text-sm font-semibold mb-2">Accès restreint</div>
        <div className="text-sm mb-4">{reason || 'Accès non autorisé.'}</div>
        <div className="text-xs text-amber-300">
          Connectez le wallet du créateur Solana ou du gestionnaire Ethereum autorisé pour utiliser cette fonctionnalité.
        </div>
      </div>
    </div>
  );
}
// Composants optimisés
function SmartNavigation({ activeTab, account, visitCount, holdersCount, holdersLoading, onNavigate, onConnectWallet, onDisconnect }) {
  const navItems = React.useMemo(() => ([
    { id: 'home', icon: Home, label: 'Accueil' },
    { id: 'upload', icon: Upload, label: 'Upload' },
    { id: 'library', icon: Album, label: 'Bibliothèque' },
    { id: 'settings', icon: Settings, label: 'Paramètres' }
  ]), []);

  return (
    <header className="sticky top-0 z-50 bg-gray-900/80 backdrop-blur-sm border-b border-gray-800">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo avec préchargement */}
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="flex items-center cursor-pointer"
            onClick={() => onNavigate('home')}
          >
            <Disc className="text-cyan-400 mr-2" />
            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">
              {CONFIG.appName}
            </span>
          </motion.div>

          {/* Navigation principale */}
          <nav className="hidden md:flex space-x-1">
            {navItems.map(item => (
              <motion.button
                key={item.id}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => onNavigate(item.id)}
                className={`px-4 py-2 rounded-md flex items-center text-sm font-medium transition-all ${
                  activeTab === item.id
                    ? 'bg-gray-800 text-cyan-400 shadow-lg'
                    : 'text-gray-400 hover:text-white hover:bg-gray-800/50'
                }`}
              >
                <item.icon className="h-5 w-5 mr-2" />
                {item.label}
              </motion.button>
            ))}
          </nav>

          {/* Stats site */}
          <SiteStats visitCount={visitCount} holdersCount={holdersCount} holdersLoading={holdersLoading} />

          {/* Wallet connect */}
          <WalletButton 
            account={account}
            onConnect={onConnectWallet}
            onDisconnect={onDisconnect}
          />
        </div>
      </div>
    </header>
  );
}

function LegalModal({ onClose }) {
  useEffect(() => {
    const onEsc = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onEsc);
    return () => window.removeEventListener('keydown', onEsc);
  }, [onClose]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center"
      aria-modal="true"
      role="dialog"
    >
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <motion.div
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="relative z-10 w-full max-w-3xl bg-gray-900 border border-gray-800 rounded-xl shadow-2xl"
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
          <div className="text-sm font-semibold text-gray-100">Mentions légales & clauses de non-responsabilité</div>
          <button onClick={onClose} className="p-2 text-gray-400 hover:text-white" aria-label="Fermer">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="max-h-[70vh] overflow-y-auto px-4 py-4 text-sm text-gray-300 space-y-4">
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">1. Aucune recommandation financière</h3>
            <p>
              Les informations, contenus et fonctionnalités de {CONFIG.appName} sont fournis à titre informatif uniquement et ne constituent
              en aucun cas un conseil financier, juridique, fiscal ou d’investissement. Vous êtes seul responsable de vos décisions et de
              l’évaluation des risques associés.
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">2. Risques liés aux actifs numériques</h3>
            <ul className="list-disc pl-5 space-y-1 text-gray-300">
              <li>Volatilité élevée des prix, perte partielle ou totale du capital possible.</li>
              <li>Risque technologique (smart contracts, réseaux, portefeuilles, clés privées).</li>
              <li>Risque réglementaire et fiscal selon votre juridiction.</li>
            </ul>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">3. Conformité réglementaire (MiCA et autres)</h3>
            <p>
              {CONFIG.appName} vise à respecter les cadres applicables, notamment le règlement européen MiCA lorsqu’il est pertinent.
              Toutefois, {CONFIG.appName} n’est pas un prestataire de services sur actifs numériques (PSAN) ni un établissement de paiement.
              Selon votre pays de résidence, des exigences supplémentaires peuvent s’appliquer. Vous devez vérifier votre conformité locale
              avant toute utilisation.
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">4. Paiements, frais et taxes</h3>
            <ul className="list-disc pl-5 space-y-1 text-gray-300">
              <li>Des frais de réseau et/ou de service peuvent s’appliquer lors des transactions.</li>
              <li>Vous êtes responsable des taxes et obligations déclaratives associées.</li>
              <li>Les taux et disponibilités peuvent varier selon la chaîne et le portefeuille.</li>
            </ul>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">5. Propriété intellectuelle et contenus</h3>
            <p>
              Vous déclarez disposer des droits nécessaires pour téléverser et distribuer vos contenus (audio, visuels). En cas de doute,
              n’uploadez pas de contenu protégé sans autorisation expresse.
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">6. Données et confidentialité</h3>
            <p>
              {CONFIG.appName} peut stocker localement des informations techniques (par ex. via localStorage) pour améliorer l’expérience.
              Aucun traitement de données personnelles au sens RGPD n’est intentionnel sans votre consentement explicite. Référez‑vous à la
              politique de confidentialité le cas échéant.
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">7. Limitation de responsabilité</h3>
            <p>
              {CONFIG.appName} est fourni “en l’état”, sans garantie de disponibilité ou d’exactitude. {CONFIG.appName} et ses contributeurs
              ne sauraient être tenus responsables des pertes directes ou indirectes liées à l’utilisation du service.
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">8. Contact</h3>
            <p>
              Pour toute question légale, contactez le support via les canaux officiels indiqués dans l’application.
            </p>
          </section>
        </div>
        <div className="px-4 py-3 border-t border-gray-800 flex justify-end">
          <button onClick={onClose} className="px-3 py-2 text-sm bg-gray-800 hover:bg-gray-700 rounded-md border border-gray-700">
            Fermer
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function PrivacyModal({ onClose }) {
  useEffect(() => {
    const onEsc = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onEsc);
    return () => window.removeEventListener('keydown', onEsc);
  }, [onClose]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center" aria-modal="true" role="dialog">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <motion.div initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="relative z-10 w-full max-w-3xl bg-gray-900 border border-gray-800 rounded-xl shadow-2xl">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
          <div className="text-sm font-semibold text-gray-100">Politique de confidentialité</div>
          <button onClick={onClose} className="p-2 text-gray-400 hover:text-white" aria-label="Fermer"><X className="h-5 w-5" /></button>
        </div>
        <div className="max-h-[70vh] overflow-y-auto px-4 py-4 text-sm text-gray-300 space-y-4">
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">1. Portée et responsabilité RGPD</h3>
            <p>
              {CONFIG.appName} applique les principes du RGPD (minimisation des données, limitation des finalités, sécurité). Par défaut,
              l’application stocke localement uniquement des informations techniques nécessaires (par ex. préférences, compteurs) via localStorage.
              Aucun profilage ni transfert de données personnelles à des tiers sans base légale appropriée.
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">2. Données collectées</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Données locales: préférences, historique de bibliothèques sur cet appareil.</li>
              <li>Wallet: adresse publique uniquement lors de la connexion (aucune clé privée).</li>
              <li>Journalisation technique minimale pour la sécurité et l’amélioration du service.</li>
            </ul>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">3. Droits des utilisateurs</h3>
            <p>
              Vous disposez de droits d’accès, rectification, effacement, limitation et opposition. Pour exercer vos droits,
              contactez-nous via les canaux de support. Les données locales peuvent être effacées depuis votre navigateur.
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">4. Cookies et stockage local</h3>
            <p>
              Nous privilégions le stockage local au navigateur. Les cookies tiers ne sont pas utilisés, sauf nécessité explicite pour une
              fonctionnalité donnée (qui fera l’objet d’un consentement spécifique).
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">5. Transferts hors UE</h3>
            <p>
              Si des prestataires non UE sont utilisés (ex. hébergement), des garanties appropriées sont mises en place (clauses contractuelles types).
            </p>
          </section>
        </div>
        <div className="px-4 py-3 border-t border-gray-800 flex justify-end">
          <button onClick={onClose} className="px-3 py-2 text-sm bg-gray-800 hover:bg-gray-700 rounded-md border border-gray-700">Fermer</button>
        </div>
      </motion.div>
    </motion.div>
  );
}

function TermsModal({ onClose }) {
  useEffect(() => {
    const onEsc = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onEsc);
    return () => window.removeEventListener('keydown', onEsc);
  }, [onClose]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 flex items-center justify-center" aria-modal="true" role="dialog">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <motion.div initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="relative z-10 w-full max-w-3xl bg-gray-900 border border-gray-800 rounded-xl shadow-2xl">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800">
          <div className="text-sm font-semibold text-gray-100">Conditions d’utilisation</div>
          <button onClick={onClose} className="p-2 text-gray-400 hover:text-white" aria-label="Fermer"><X className="h-5 w-5" /></button>
        </div>
        <div className="max-h-[70vh] overflow-y-auto px-4 py-4 text-sm text-gray-300 space-y-4">
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">1. Objet du service</h3>
            <p>
              {CONFIG.appName} fournit des fonctionnalités de téléversement, prévisualisation et gestion de contenus audio/visuels, avec intégrations web3.
              L’utilisation implique l’acceptation pleine et entière des présentes conditions.
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">2. Utilisation licite</h3>
            <p>
              Interdiction de toute activité illicite (contrefaçon, fraude, malware). Respect des droits d’auteur et des lois applicables.
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">3. Comptes et portefeuilles</h3>
            <p>
              Vous êtes responsable de la sécurité de vos portefeuilles et appareils. {CONFIG.appName} ne stocke pas vos clés privées.
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">4. Limitation et suspension</h3>
            <p>
              {CONFIG.appName} peut limiter, suspendre ou interrompre l’accès en cas de violation des présentes conditions ou pour raisons techniques.
            </p>
          </section>
          <section>
            <h3 className="text-gray-100 font-semibold mb-2">5. Droit applicable</h3>
            <p>
              Sous réserve des règles d’ordre public, les litiges seront tranchés par les juridictions compétentes du siège de l’éditeur.
            </p>
          </section>
        </div>
        <div className="px-4 py-3 border-t border-gray-800 flex justify-end">
          <button onClick={onClose} className="px-3 py-2 text-sm bg-gray-800 hover:bg-gray-700 rounded-md border border-gray-700">Fermer</button>
        </div>
      </motion.div>
    </motion.div>
  );
}
function UploadFlow({ account, onAudioPreview, audioPreview }) {
  const [step, setStep] = useState('select');
  const [contentType, setContentType] = useState(null);
  const [files, setFiles] = useState([]);
  const [metadata, setMetadata] = useState({
    title: '',
    description: '',
    isOriginal: true,
    royalty: 10
  });
  const [showcaseId, setShowcaseId] = useState(CONFIG.showcases[0]?.id || 'vitrine-principale');
  const [prepareAsNft, setPrepareAsNft] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({});
  const [uploadTotalProgress, setUploadTotalProgress] = useState(0);
  const [uploadXhrs, setUploadXhrs] = useState({});

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: acceptedFiles => {
      const safeFiles = acceptedFiles.filter(file => {
        if (file.size > CONFIG.security.maxFileSizeBytes) {
          toast.error(`Fichier trop volumineux: ${file.name}`);
          return false;
        }
        return true;
      });
      const processedFiles = safeFiles.map(file => {
        const preview = URL.createObjectURL(file);
        if (file.type.startsWith('audio/')) {
          onAudioPreview(file);
        }
        return { ...file, preview };
      });
      setFiles(processedFiles);
      setStep('metadata');
    },
    accept: {
      'audio/*': ['.mp3', '.wav', '.aac', '.m4a'],
      'video/mp4': ['.mp4'],
      'image/*': ['.jpg', '.jpeg', '.png']
    },
    maxFiles: 3
  });

  useEffect(() => {
    return () => {
      files.forEach(file => {
        if (file?.preview) {
          URL.revokeObjectURL(file.preview);
        }
      });
    };
  }, [files]);

  return (
    <div className="max-w-4xl mx-auto">
      {/* Assistant visuel */}
      <UploadProgress step={step} />

      {/* Sélection du type */}
      {step === 'select' && (
        <ContentTypeSelector 
          onSelect={(type) => {
            setContentType(type);
            setStep('upload');
          }}
        />
      )}

      {/* Téléversement */}
      {step === 'upload' && (
        <div {...getRootProps()} className="border-2 border-dashed border-gray-700 rounded-xl p-12 text-center cursor-pointer hover:border-cyan-500 transition-colors">
          <input {...getInputProps()} />
          <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-lg">
            {isDragActive 
              ? "Déposez vos fichiers ici" 
              : "Glissez-déposez vos fichiers audio/images"}
          </p>
        </div>
      )}

      {/* Métadonnées */}
      {step === 'metadata' && (
        <div className="space-y-6">
          <MetadataForm 
            files={files}
            metadata={metadata}
            onChange={setMetadata}
            onSubmit={() => setStep('review')}
          />
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-300 mb-2">Vitrine de destination</label>
              <select
                value={showcaseId}
                onChange={(e) => setShowcaseId(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded-md p-2 text-sm"
              >
                {CONFIG.showcases.map(s => (
                  <option key={s.id} value={s.id}>{s.label}</option>
                ))}
              </select>
            </div>
            <div className="flex items-center">
              <input
                id="prepare-nft"
                type="checkbox"
                checked={prepareAsNft}
                onChange={(e) => setPrepareAsNft(e.target.checked)}
                className="mr-2"
              />
              <label htmlFor="prepare-nft" className="text-sm text-gray-300">
                Préparer comme NFT (mise en file d’attente)
              </label>
            </div>
          </div>
        </div>
      )}

      {/* Revue finale */}
      {step === 'review' && (
        <div className="space-y-6">
          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <div className="text-xs uppercase text-gray-400 mb-1">Vitrine</div>
                <div className="text-sm text-gray-200">
                  {CONFIG.showcases.find(s => s.id === showcaseId)?.label || showcaseId}
                </div>
              </div>
              <div>
                <div className="text-xs uppercase text-gray-400 mb-1">Préparer comme NFT</div>
                <div className="text-sm text-gray-200">{prepareAsNft ? 'Oui' : 'Non'}</div>
              </div>
            </div>
          </div>
          <ReviewStep 
            files={files}
            metadata={metadata}
            account={account}
            onConfirm={async () => {
              try {
                setUploading(true);
                setUploadProgress({});
                setUploadTotalProgress(0);
                setUploadXhrs({});
                // Enregistrer un brouillon "en cours" dans la vitrine
                const draftId = `${Date.now()}`;
                const writeDraft = (payloadPartial) => {
                  const existing = JSON.parse(localStorage.getItem('djp_showcases') || '{}');
                  const items = existing[showcaseId] || [];
                  const idx = items.findIndex(it => it.id === draftId);
                  const base = idx >= 0 ? items[idx] : { id: draftId, createdAt: new Date().toISOString(), showcaseId };
                  const nextItem = { ...base, ...payloadPartial };
                  const newItems = idx >= 0 ? [...items.slice(0, idx), nextItem, ...items.slice(idx + 1)] : [nextItem, ...items];
                  const capped = newItems.slice(0, CONFIG.security.maxShowcaseItems);
                  const updated = { ...existing, [showcaseId]: capped };
                  localStorage.setItem('djp_showcases', JSON.stringify(updated));
                };
                writeDraft({
                  status: 'uploading',
                  progressTotal: 0,
                  files: files.map(f => ({ name: f.name, type: f.type, size: f.size })),
                  metadata,
                  account,
                  prepareAsNft
                });
                const sleep = (ms) => new Promise(r => setTimeout(r, ms));
                const putWithProgress = (url, headers, file, onProgress, onXhrReady) =>
                  new Promise((resolve, reject) => {
                    const xhr = new XMLHttpRequest();
                    xhr.upload.onprogress = (e) => {
                      if (e.lengthComputable && typeof onProgress === 'function') {
                        onProgress(e.loaded / e.total);
                      }
                    };
                    xhr.onload = () => {
                      if (xhr.status >= 200 && xhr.status < 300) resolve(null);
                      else reject(new Error(`Upload HTTP ${xhr.status}`));
                    };
                    xhr.onerror = () => reject(new Error('Erreur réseau pendant l’upload'));
                    xhr.onabort = () => reject(new Error('Upload annulé'));
                    xhr.open('PUT', url, true);
                    if (headers) {
                      Object.entries(headers).forEach(([k, v]) => {
                        try { xhr.setRequestHeader(k, v); } catch {}
                      });
                    }
                    if (typeof onXhrReady === 'function') onXhrReady(xhr);
                    xhr.send(file);
                  });
                const signFile = async (file) => {
                  const resp = await fetch('/api/upload/sign', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: file.name, type: file.type, size: file.size })
                  });
                  if (!resp.ok) {
                    const err = await resp.json().catch(() => ({}));
                    throw new Error(err?.error || 'Signature upload échouée');
                  }
                  return resp.json();
                };
                const uploadOneWithRetry = async (file, maxAttempts = 3) => {
                  let attempt = 0;
                  while (attempt < maxAttempts) {
                    try {
                      const { uploadUrl, objectUrl, headers: putHeaders } = await signFile(file);
                      await putWithProgress(uploadUrl, putHeaders || {}, file, (p) => {
                        setUploadProgress(prev => {
                          const next = { ...prev, [file.name]: Math.round(p * 100) };
                          const values = files.map(f => next[f.name] || 0);
                          const avg = Math.round(values.reduce((a, b) => a + b, 0) / Math.max(values.length, 1));
                          setUploadTotalProgress(avg);
                          writeDraft({ progressTotal: avg });
                          return next;
                        });
                      }, (xhr) => {
                        setUploadXhrs(prev => ({ ...prev, [file.name]: xhr }));
                      });
                      return { file, publicUrl: objectUrl };
                    } catch (e) {
                      attempt += 1;
                      if (attempt >= maxAttempts) throw e;
                      await sleep(500 * attempt);
                    }
                  }
                };
                // 1) Uploader chaque fichier via URL pré-signée
                const uploaded = [];
                for (const f of files) {
                  const result = await uploadOneWithRetry(f, 3);
                  uploaded.push(result);
                }

                const readAsDataURL = (file) =>
                  new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onload = () => resolve(reader.result);
                    reader.onerror = reject;
                    reader.readAsDataURL(file);
                  });
                const filesWithPreviews = await Promise.all(
                  uploaded.map(async ({ file: f, publicUrl }) => {
                    let dataUrlPreview = null;
                    if (f.type?.startsWith('image/')) {
                      try {
                        // DataURL persistant pour miniatures images (limité en taille)
                        if (f.size <= CONFIG.security.maxImagePreviewBytes) {
                          dataUrlPreview = await readAsDataURL(f);
                        }
                      } catch {
                        dataUrlPreview = null;
                      }
                    }
                    return {
                      name: f.name,
                      type: f.type,
                      size: f.size,
                      // L’URL persistante vers le stockage (S3/Supabase)
                      url: publicUrl,
                      // Conserver éventuellement le blob: pour prévisualisation immédiate pendant la session
                      preview: f.preview,
                      dataUrlPreview
                    };
                  })
                );

                // Remplacer le brouillon par l’entrée finale
                writeDraft({
                  status: 'completed',
                  progressTotal: 100,
                  files: filesWithPreviews
                });
                toast.success('Contenu enregistré dans la vitrine sélectionnée');
                setStep('complete');
                setUploading(false);
              } catch (e) {
                setUploading(false);
                toast.error(`Échec de l’enregistrement: ${e.message}`);
              }
            }}
          />
          {uploading && (
            <div className="space-y-2">
              <div className="text-xs text-gray-400">Progression globale: {uploadTotalProgress}%</div>
              <div className="h-2 bg-gray-800 rounded">
                <div className="h-2 bg-cyan-600 rounded" style={{ width: `${uploadTotalProgress}%` }} />
              </div>
              {files.map((f) => {
                const pct = uploadProgress[f.name] ?? 0;
                return (
                  <div key={f.name} className="text-xs">
                    <div className="flex justify-between mb-1">
                      <span className="truncate mr-2 text-gray-300">{f.name}</span>
                      <span className="text-gray-400">{pct}%</span>
                    </div>
                    <div className="h-2 bg-gray-800 rounded">
                      <div className="h-2 bg-cyan-600 rounded" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
              <div className="pt-2">
                <button
                  className="px-3 py-2 text-xs bg-red-700 hover:bg-red-800 rounded border border-red-900 text-red-100"
                  onClick={() => {
                    Object.values(uploadXhrs).forEach((xhr) => {
                      try { xhr.abort(); } catch {}
                    });
                    setUploading(false);
                    setUploadXhrs({});
                    setUploadProgress({});
                    setUploadTotalProgress(0);
                    // Marquer le brouillon en annulé
                    try {
                      const existing = JSON.parse(localStorage.getItem('djp_showcases') || '{}');
                      const items = existing[showcaseId] || [];
                      const idx = items.findIndex(it => it.status === 'uploading');
                      if (idx >= 0) {
                        items[idx] = { ...items[idx], status: 'cancelled' };
                        const updated = { ...existing, [showcaseId]: items };
                        localStorage.setItem('djp_showcases', JSON.stringify(updated));
                      }
                    } catch {}
                  }}
                >
                  Annuler les uploads
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Confirmation */}
      {step === 'complete' && (
        <UploadSuccess 
          onNewUpload={() => {
            setStep('select');
            setFiles([]);
          }}
        />
      )}
    </div>
  );
}

// Composants supplémentaires optimisés
const WalletButton = React.memo(function WalletButton({ account, onConnect, onDisconnect }) {
  const [menuOpen, setMenuOpen] = useState(false);
  useEffect(() => {
    const onEsc = (e) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    window.addEventListener('keydown', onEsc);
    return () => window.removeEventListener('keydown', onEsc);
  }, []);

  const isCreator = account?.chain === 'solana' && account?.address === CONFIG.creatorAddress;
  const isManager = account?.chain === 'ethereum' && account?.address?.toLowerCase() === CONFIG.managerAddress?.toLowerCase();

  return (
    <>
      {account ? (
        <div className="relative">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setMenuOpen((v) => !v)}
            className="flex items-center px-4 py-2 rounded-full text-sm bg-green-900/30 text-green-400 border border-green-800/50"
            aria-expanded={menuOpen}
            aria-haspopup="menu"
            aria-label={`Connecté à ${account.chain}. Changer de chaîne`}
          >
            <Wallet className="h-4 w-4 mr-2" />
            <span className="font-mono mr-2">
              {`${account.address.substring(0, 6)}...${account.address.substring(account.address.length - 4)}`}
            </span>
            <span className="px-2 py-0.5 text-xs rounded bg-green-800/40 border border-green-700/40 capitalize">
              {account.chain}
            </span>
            {isCreator && (
              <span className="ml-2 px-2 py-0.5 text-xs rounded bg-cyan-800/40 border border-cyan-700/40 text-cyan-200">
                Créateur
              </span>
            )}
            {isManager && (
              <span className="ml-2 px-2 py-0.5 text-xs rounded bg-purple-800/40 border border-purple-700/40 text-purple-200">
                Gestion
              </span>
            )}
          </motion.button>
          {menuOpen && (
            <div
              role="menu"
              className="absolute right-0 mt-2 w-40 bg-gray-900 border border-gray-800 rounded-lg shadow-lg z-50"
            >
              <button
                className="w-full text-left px-3 py-2 text-sm hover:bg-gray-800 rounded-t-lg"
                onClick={() => {
                  setMenuOpen(false);
                  onConnect('ethereum');
                }}
                aria-label="Basculer vers Ethereum"
              >
                Ethereum
              </button>
              <button
                className="w-full text-left px-3 py-2 text-sm hover:bg-gray-800"
                onClick={() => {
                  setMenuOpen(false);
                  onConnect('solana');
                }}
                aria-label="Basculer vers Solana"
              >
                Solana
              </button>
              <div className="h-px bg-gray-800 my-1" />
              <button
                className="w-full text-left px-3 py-2 text-sm hover:bg-gray-800 rounded-b-lg text-red-300"
                onClick={() => {
                  setMenuOpen(false);
                  onDisconnect && onDisconnect();
                }}
                aria-label="Se déconnecter"
              >
                Déconnecter
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="flex items-center space-x-2">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onConnect('ethereum')}
            className="flex items-center px-3 py-2 rounded-full text-sm bg-cyan-600 hover:bg-cyan-700 text-white"
            aria-label="Se connecter avec Ethereum"
          >
            <Wallet className="h-4 w-4 mr-2" />
            <span>Ethereum</span>
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onConnect('solana')}
            className="flex items-center px-3 py-2 rounded-full text-sm bg-purple-600 hover:bg-purple-700 text-white"
            aria-label="Se connecter avec Solana"
          >
            <Wallet className="h-4 w-4 mr-2" />
            <span>Solana</span>
          </motion.button>
        </div>
      )}
    </>
  );
});

function GlobalAudioPlayer({ src, onClose }) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  const togglePlay = () => {
    if (!audioManager.player) return;
    if (playing) {
      audioManager.player.pause();
    } else {
      audioManager.player.play();
    }
    setPlaying(!playing);
  };

  useEffect(() => {
    const updateProgress = () => {
      if (!audioManager.player) return;
      const seek = audioManager.player.seek() || 0;
      const duration = audioManager.player.duration() || 1;
      setProgress((seek / duration) * 100);
    };

    const interval = setInterval(updateProgress, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      exit={{ y: 100 }}
      className="fixed bottom-0 left-0 right-0 bg-gray-800/90 backdrop-blur-sm border-t border-gray-700 z-50"
    >
      <div className="container mx-auto px-4 py-3 flex items-center">
        <button
          onClick={togglePlay}
          className="p-2 rounded-full bg-cyan-600 hover:bg-cyan-700 mr-4"
          aria-label={playing ? 'Pause' : 'Lecture'}
          disabled={!audioManager.player}
        >
          {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
        </button>
        
        <div className="flex-1">
          <div className="h-1 bg-gray-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-cyan-500" 
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
        
        <button
          onClick={onClose}
          className="ml-4 p-2 text-gray-400 hover:text-white"
          aria-label="Fermer le lecteur"
        >
          <X className="h-5 w-5" />
        </button>
      </div>
    </motion.div>
  );
}

function LibraryPage() {
  const [showcaseFilter, setShowcaseFilter] = useState('all');
  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [items, setItems] = useState([]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem('djp_showcases');
      const parsed = raw ? JSON.parse(raw) : {};
      const flattened = Object.entries(parsed).flatMap(([sid, entries]) =>
        entries.map(entry => ({ ...entry, showcaseId: sid }))
      );
      setItems(flattened);
    } catch {
      setItems([]);
    }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query), 250);
    return () => clearTimeout(t);
  }, [query]);

  const filtered = React.useMemo(() => {
    const q = debouncedQuery.toLowerCase();
    return items.filter(entry => {
      const matchShowcase = showcaseFilter === 'all' || entry.showcaseId === showcaseFilter;
      if (!matchShowcase) return false;
      if (!q) return true;
      const metaTitle = (entry.metadata?.title || '').toLowerCase();
      const metaDesc = (entry.metadata?.description || '').toLowerCase();
      const fileNames = (entry.files || []).map(f => f.name?.toLowerCase() || '');
      return (
        metaTitle.includes(q) ||
        metaDesc.includes(q) ||
        fileNames.some(n => n.includes(q))
      );
    });
  }, [items, showcaseFilter, debouncedQuery]);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="grid sm:grid-cols-3 gap-4">
        <div className="sm:col-span-1">
          <label className="block text-sm text-gray-300 mb-2">Vitrine</label>
          <select
            value={showcaseFilter}
            onChange={(e) => setShowcaseFilter(e.target.value)}
            className="w-full bg-gray-800 border border-gray-700 rounded-md p-2 text-sm"
          >
            <option value="all">Toutes vitrines</option>
            {CONFIG.showcases.map(s => (
              <option key={s.id} value={s.id}>{s.label}</option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="block text-sm text-gray-300 mb-2">Recherche</label>
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Titre, description, nom de fichier…"
            className="w-full bg-gray-800 border border-gray-700 rounded-md p-2 text-sm"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="text-gray-400 text-sm">Aucun élément trouvé.</div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map(entry => (
            <div key={entry.id} className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
              {/* Aperçu principal si image disponible */}
              {(() => {
                const img = (entry.files || []).find(f =>
                  (f.type?.startsWith('image/') && (f.dataUrlPreview || f.url))
                );
                if (img) {
                  return (
                    <div className="mb-3">
                      <img
                        src={img.dataUrlPreview || img.url}
                        alt={img.name || 'aperçu'}
                        className="w-full h-40 object-cover rounded-md border border-gray-700"
                      />
                    </div>
                  );
                }
                return null;
              })()}
              <div className="flex items-center justify-between mb-2">
                <div className="text-sm font-semibold text-gray-100">
                  {entry.metadata?.title || 'Sans titre'}
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-xs px-2 py-0.5 rounded bg-gray-700 text-gray-300">
                    {CONFIG.showcases.find(s => s.id === entry.showcaseId)?.label || entry.showcaseId}
                  </span>
                  {entry.status && (
                    <span className={`text-xs px-2 py-0.5 rounded border ${
                      entry.status === 'uploading'
                        ? 'bg-amber-900/30 text-amber-200 border-amber-800/50'
                        : entry.status === 'completed'
                        ? 'bg-green-900/30 text-green-300 border-green-800/50'
                        : 'bg-red-900/30 text-red-300 border-red-800/50'
                    }`}>
                      {entry.status === 'uploading' ? 'En cours' : entry.status === 'completed' ? 'Terminé' : 'Annulé'}
                    </span>
                  )}
                </div>
              </div>
              <div className="text-xs text-gray-400 mb-3">
                {entry.metadata?.description || '—'}
              </div>
              {entry.status === 'uploading' && typeof entry.progressTotal === 'number' && (
                <div className="mb-3">
                  <div className="text-2xs text-gray-400 mb-1">Progression: {entry.progressTotal}%</div>
                  <div className="h-2 bg-gray-900 rounded">
                    <div className="h-2 bg-amber-500 rounded" style={{ width: `${entry.progressTotal}%` }} />
                  </div>
                </div>
              )}
              <div className="space-y-2">
                {(entry.files || []).map((f, idx) => (
                  <div key={idx} className="text-xs bg-gray-900/40 border border-gray-800 rounded p-2">
                    <div className="flex items-center justify-between">
                      <div className="truncate mr-2">{f.name}</div>
                      <div className="flex items-center space-x-2">
                        {f.type?.startsWith('image/') && f.dataUrlPreview && (
                          <span className="text-gray-400">Image</span>
                        )}
                        {f.type?.startsWith('audio/') && (
                          <span
                            className="px-2 py-0.5 rounded bg-cyan-700/40 text-cyan-300 border border-cyan-700/40"
                            title={f.url ? 'Aperçu persistant' : (!f.preview || !f.preview.startsWith('blob:') ? 'Aperçu non disponible après rechargement' : 'Aperçu audio (session courante)')}
                          >
                            Audio
                          </span>
                        )}
                        {f.type === 'video/mp4' && (
                          <span className="px-2 py-0.5 rounded bg-purple-700/30 text-purple-200 border border-purple-700/30">
                            Vidéo
                          </span>
                        )}
                      </div>
                    </div>
                    {f.type?.startsWith('audio/') && (f.url || (f.preview && f.preview.startsWith('blob:'))) && (
                      <div className="mt-2">
                        <audio controls src={f.url || f.preview} className="w-full" />
                      </div>
                    )}
                    {f.type === 'video/mp4' && (f.url || (f.preview && f.preview.startsWith('blob:'))) && (
                      <div className="mt-2">
                        <video controls src={f.url || f.preview} className="w-full rounded" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <div className="mt-3 flex items-center justify-between">
                <div className="text-xs text-gray-500">
                  {entry.prepareAsNft ? 'Préparé comme NFT' : 'Standard'}
                </div>
                <div className="text-xs text-gray-500">
                  {new Date(entry.createdAt).toLocaleString()}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Composants manquants pour le fonctionnement complet
function HomePage() {
  return (
    <div className="max-w-4xl mx-auto text-center space-y-8 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">
          Bienvenue sur {CONFIG.appName}
        </h1>
        <p className="text-gray-400 text-lg">
          Plateforme révolutionnaire de gestion de contenus audio/visuels avec intégration Web3
        </p>
      </motion.div>
      <div className="grid md:grid-cols-3 gap-6 mt-12">
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-gray-800/50 border border-gray-700 rounded-lg p-6"
        >
          <Disc className="h-12 w-12 text-cyan-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Bibliothèque</h3>
          <p className="text-sm text-gray-400">Explorez vos contenus organisés par vitrines</p>
        </motion.div>
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-gray-800/50 border border-gray-700 rounded-lg p-6"
        >
          <Upload className="h-12 w-12 text-cyan-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Upload</h3>
          <p className="text-sm text-gray-400">Téléversez vos fichiers audio, vidéo et images</p>
        </motion.div>
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="bg-gray-800/50 border border-gray-700 rounded-lg p-6"
        >
          <Wallet className="h-12 w-12 text-cyan-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Web3</h3>
          <p className="text-sm text-gray-400">Connectez votre wallet Ethereum ou Solana</p>
        </motion.div>
      </div>
    </div>
  );
}

function UploadProgress({ step }) {
  const steps = ['select', 'upload', 'metadata', 'review', 'complete'];
  const labels = ['Sélection', 'Upload', 'Métadonnées', 'Revue', 'Terminé'];
  const currentIndex = steps.indexOf(step);

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between">
        {steps.map((s, idx) => (
          <div key={s} className="flex items-center flex-1">
            <div className={`flex items-center justify-center w-8 h-8 rounded-full border-2 ${
              idx <= currentIndex
                ? 'bg-cyan-600 border-cyan-500 text-white'
                : 'bg-gray-800 border-gray-700 text-gray-500'
            }`}>
              {idx + 1}
            </div>
            {idx < steps.length - 1 && (
              <div className={`flex-1 h-1 mx-2 ${
                idx < currentIndex ? 'bg-cyan-600' : 'bg-gray-700'
              }`} />
            )}
          </div>
        ))}
      </div>
      <div className="text-center mt-2 text-sm text-gray-400">
        {labels[currentIndex] || 'Étape inconnue'}
      </div>
    </div>
  );
}

function ContentTypeSelector({ onSelect }) {
  return (
    <div className="grid md:grid-cols-2 gap-4">
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => onSelect('audio')}
        className="p-6 bg-gray-800/50 border border-gray-700 rounded-lg hover:border-cyan-500 transition-colors"
      >
        <Headphones className="h-12 w-12 text-cyan-400 mx-auto mb-4" />
        <div className="text-lg font-semibold">Audio</div>
      </motion.button>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => onSelect('mixed')}
        className="p-6 bg-gray-800/50 border border-gray-700 rounded-lg hover:border-cyan-500 transition-colors"
      >
        <Disc className="h-12 w-12 text-cyan-400 mx-auto mb-4" />
        <div className="text-lg font-semibold">Mixte (Audio + Images)</div>
      </motion.button>
    </div>
  );
}

function MetadataForm({ files, metadata, onChange, onSubmit }) {
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm text-gray-300 mb-2">Titre *</label>
        <input
          value={metadata.title}
          onChange={(e) => onChange({ ...metadata, title: e.target.value })}
          className="w-full bg-gray-800 border border-gray-700 rounded-md p-2 text-sm"
          required
        />
      </div>
      <div>
        <label className="block text-sm text-gray-300 mb-2">Description</label>
        <textarea
          value={metadata.description}
          onChange={(e) => onChange({ ...metadata, description: e.target.value })}
          rows={4}
          className="w-full bg-gray-800 border border-gray-700 rounded-md p-2 text-sm"
        />
      </div>
      <div className="flex items-center">
        <input
          type="checkbox"
          checked={metadata.isOriginal}
          onChange={(e) => onChange({ ...metadata, isOriginal: e.target.checked })}
          className="mr-2"
        />
        <label className="text-sm text-gray-300">Contenu original</label>
      </div>
      <div>
        <label className="block text-sm text-gray-300 mb-2">Royalty (%)</label>
        <input
          type="number"
          min="0"
          max="100"
          value={metadata.royalty}
          onChange={(e) => onChange({ ...metadata, royalty: parseInt(e.target.value || '0', 10) })}
          className="w-full bg-gray-800 border border-gray-700 rounded-md p-2 text-sm"
        />
      </div>
      <button
        onClick={onSubmit}
        disabled={!metadata.title}
        className="w-full px-4 py-2 bg-cyan-600 hover:bg-cyan-700 rounded-md text-white disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Continuer
      </button>
    </div>
  );
}

function ReviewStep({ files, metadata, account, onConfirm }) {
  return (
    <div className="space-y-4">
      <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
        <div className="text-sm font-semibold text-gray-100 mb-2">Métadonnées</div>
        <div className="text-xs text-gray-400 space-y-1">
          <div>Titre: {metadata.title || '—'}</div>
          <div>Description: {metadata.description || '—'}</div>
          <div>Original: {metadata.isOriginal ? 'Oui' : 'Non'}</div>
          <div>Royalty: {metadata.royalty}%</div>
        </div>
      </div>
      <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
        <div className="text-sm font-semibold text-gray-100 mb-2">Fichiers ({files.length})</div>
        <div className="text-xs text-gray-400 space-y-1">
          {files.map((f, idx) => (
            <div key={idx}>{f.name} ({(f.size / 1024 / 1024).toFixed(2)} MB)</div>
          ))}
        </div>
      </div>
      {account && (
        <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4">
          <div className="text-sm font-semibold text-gray-100 mb-2">Wallet connecté</div>
          <div className="text-xs text-gray-400 font-mono">
            {account.address.substring(0, 10)}...{account.address.substring(account.address.length - 8)}
          </div>
        </div>
      )}
      <button
        onClick={onConfirm}
        className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 rounded-md text-white"
      >
        Confirmer et enregistrer
      </button>
    </div>
  );
}

function UploadSuccess({ onNewUpload }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="text-center space-y-6 py-12"
    >
      <div className="text-6xl mb-4">✅</div>
      <h2 className="text-2xl font-bold text-gray-100">Upload réussi !</h2>
      <p className="text-gray-400">Votre contenu a été enregistré avec succès.</p>
      <button
        onClick={onNewUpload}
        className="px-6 py-3 bg-cyan-600 hover:bg-cyan-700 rounded-md text-white"
      >
        Nouvel upload
      </button>
    </motion.div>
  );
}