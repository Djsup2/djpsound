/** @type {import('next').NextConfig} */
const nextConfig = {
	output: 'standalone', // Pour Docker et déploiements optimisés
	
	// Optimisations de performance
	compress: true, // Compression Gzip
	poweredByHeader: false, // Retirer le header X-Powered-By pour la sécurité
	
	// Optimisation des images
	images: {
		formats: ['image/avif', 'image/webp'],
		deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
		imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
		minimumCacheTTL: 60,
	},
	
	// Optimisations de compilation
	swcMinify: true, // Utiliser SWC pour la minification (plus rapide)
	
	// Experimental features pour performance
	experimental: {
		optimizeCss: true, // Optimisation CSS
	},
	
	async headers() {
		// Content Security Policy (ajustez les domaines autorisés si besoin)
		const csp = [
			"default-src 'self'",
			"img-src 'self' data: blob:",
			"media-src 'self' blob:",
			"connect-src 'self' https:",
			// Si vous utilisez des scripts inline, conservez 'unsafe-inline'/'unsafe-eval' (sinon retirez-les)
			"script-src 'self' 'unsafe-inline' 'unsafe-eval'",
			"style-src 'self' 'unsafe-inline'",
			"frame-ancestors 'none'",
			"base-uri 'self'",
			"form-action 'self'",
			"upgrade-insecure-requests",
		].join('; ');

		return [
			{
				source: '/:path*',
				headers: [
					{ key: 'Content-Security-Policy', value: csp },
					{ key: 'X-Content-Type-Options', value: 'nosniff' },
					{ key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
					{ key: 'X-Frame-Options', value: 'DENY' },
					// HSTS: activez uniquement si vous servez en HTTPS et que le domaine est prêt
					{ key: 'Strict-Transport-Security', value: 'max-age=31536000; includeSubDomains; preload' },
					// Optionnel: Permissions-Policy (à ajuster)
					{ key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
				],
			},
		];
	},
};

module.exports = nextConfig;


