import { Html, Head, Main, NextScript } from 'next/document';

export default function Document() {
  return (
    <Html lang="fr">
      <Head>
        {/* Meta tags SEO de base */}
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        
        {/* Favicon */}
        <link rel="icon" href="/favicon.ico" />
        
        {/* PWA Manifest */}
        <link rel="manifest" href="/manifest.json" />
        
        {/* Apple Touch Icon */}
        <link rel="apple-touch-icon" href="/icon-192.png" />
        
        {/* Preconnect pour améliorer les performances */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://api.mainnet-beta.solana.com" />
        <link rel="dns-prefetch" href="https://public-api.solscan.io" />
        <link rel="dns-prefetch" href="https://public-api.birdeye.so" />
        
        {/* Meta tags par défaut (seront surchargés par page) */}
        <meta name="description" content="DJP Sound Revolution - Plateforme révolutionnaire de gestion de contenus audio/visuels avec intégration Web3 (Ethereum & Solana)" />
        <meta name="keywords" content="musique, audio, NFT, Web3, Ethereum, Solana, blockchain, créateurs" />
        <meta name="author" content="DJP Sound Revolution" />
        <meta name="robots" content="index, follow" />
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="DJP Sound Revolution" />
        <meta property="og:title" content="DJP Sound Revolution - Plateforme Web3 pour créateurs" />
        <meta property="og:description" content="Plateforme révolutionnaire de gestion de contenus audio/visuels avec intégration Web3" />
        <meta property="og:image" content="/og-image.jpg" />
        <meta property="og:url" content="https://revoledj.com" />
        <meta property="og:locale" content="fr_FR" />
        
        {/* Twitter Card */}
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="DJP Sound Revolution" />
        <meta name="twitter:description" content="Plateforme révolutionnaire de gestion de contenus audio/visuels avec intégration Web3" />
        <meta name="twitter:image" content="/og-image.jpg" />
        
        {/* Theme color */}
        <meta name="theme-color" content="#0f172a" />
        
        {/* Apple */}
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="DJP Sound" />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}

