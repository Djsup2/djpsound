# 🚀 Guide de déploiement en production

## 📋 Préparation avant déploiement

### 1. Build de production local (test)

```bash
npm run build
npm start
```

Testez sur http://localhost:3000 pour vérifier que tout fonctionne.

### 2. Variables d'environnement

Créez un fichier `.env.production` avec vos variables :

```env
# Blockchain
NEXT_PUBLIC_ETH_RPC=https://mainnet.infura.io/v3/VOTRE_CLE
NEXT_PUBLIC_BIRDEYE_API_KEY=votre_cle_birdeye

# Upload (si activé)
UPLOAD_BACKEND=s3
S3_REGION=us-east-1
S3_BUCKET=mon-bucket
S3_ACCESS_KEY=AKIA...
S3_SECRET_KEY=...
# OU
UPLOAD_BACKEND=supabase
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_SERVICE_ROLE=eyJ...
SUPABASE_BUCKET=media

# Taille max upload
UPLOAD_MAX_SIZE_BYTES=209715200
```

## 🌐 Option 1 : Vercel (Recommandé - Gratuit)

### Avantages
- ✅ Gratuit pour les projets personnels
- ✅ Déploiement automatique depuis GitHub
- ✅ HTTPS automatique
- ✅ CDN global
- ✅ Variables d'environnement sécurisées

### Étapes

1. **Créer un compte Vercel**
   - Allez sur https://vercel.com
   - Connectez-vous avec GitHub/GitLab/Bitbucket

2. **Préparer votre code**
   ```bash
   # Initialiser Git (si pas déjà fait)
   git init
   git add .
   git commit -m "Initial commit"
   
   # Créer un repo GitHub et pousser
   git remote add origin https://github.com/votre-username/djp-sound-ultimate.git
   git push -u origin main
   ```

3. **Déployer sur Vercel**
   - Allez sur https://vercel.com/new
   - Importez votre repo GitHub
   - Vercel détecte automatiquement Next.js
   - Configurez les variables d'environnement dans "Environment Variables"
   - Cliquez sur "Deploy"

4. **Configuration Vercel**
   - **Framework Preset** : Next.js
   - **Build Command** : `npm run build` (automatique)
   - **Output Directory** : `.next` (automatique)
   - **Install Command** : `npm install` (automatique)

5. **Variables d'environnement**
   - Dans les paramètres du projet Vercel
   - Onglet "Environment Variables"
   - Ajoutez toutes vos variables (voir `.env.production`)

✅ **Votre site sera accessible sur : `votre-projet.vercel.app`**

### Domaine personnalisé (optionnel)
- Dans les paramètres du projet → "Domains"
- Ajoutez votre domaine
- Suivez les instructions DNS

---

## 🌐 Option 2 : Netlify

### Étapes

1. **Créer un compte Netlify**
   - https://www.netlify.com
   - Connectez-vous avec GitHub

2. **Déployer**
   - "Add new site" → "Import an existing project"
   - Connectez votre repo GitHub
   - Configuration :
     - **Build command** : `npm run build`
     - **Publish directory** : `.next`
   - Ajoutez les variables d'environnement
   - Cliquez sur "Deploy site"

✅ **Votre site sera sur : `votre-projet.netlify.app`**

---

## 🌐 Option 3 : Serveur VPS (VPS, DigitalOcean, AWS EC2)

### Prérequis
- Serveur Linux (Ubuntu 20.04+ recommandé)
- Node.js 18+ installé
- Nginx (optionnel, pour reverse proxy)
- PM2 (pour gérer le processus Node.js)

### Étapes

1. **Sur votre serveur, clonez le projet**
   ```bash
   git clone https://github.com/votre-username/djp-sound-ultimate.git
   cd djp-sound-ultimate
   ```

2. **Installez les dépendances**
   ```bash
   npm install --production
   ```

3. **Créez `.env.production`**
   ```bash
   nano .env.production
   # Collez vos variables d'environnement
   ```

4. **Build de production**
   ```bash
   npm run build
   ```

5. **Installez PM2**
   ```bash
   npm install -g pm2
   ```

6. **Démarrez avec PM2**
   ```bash
   pm2 start npm --name "djp-sound" -- start
   pm2 save
   pm2 startup
   ```

7. **Configuration Nginx (optionnel mais recommandé)**
   ```nginx
   server {
       listen 80;
       server_name votre-domaine.com;
       
       location / {
           proxy_pass http://localhost:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

8. **HTTPS avec Let's Encrypt**
   ```bash
   sudo apt install certbot python3-certbot-nginx
   sudo certbot --nginx -d votre-domaine.com
   ```

---

## 🌐 Option 4 : Docker (Avancé)

### Créer Dockerfile

Créez un fichier `Dockerfile` :

```dockerfile
FROM node:18-alpine AS base

# Install dependencies only when needed
FROM base AS deps
WORKDIR /app
COPY package.json package-lock.json* ./
RUN npm ci

# Rebuild the source code only when needed
FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

# Production image
FROM base AS runner
WORKDIR /app

ENV NODE_ENV production

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs

EXPOSE 3000

ENV PORT 3000

CMD ["node", "server.js"]
```

### Build et déploiement

```bash
# Build l'image
docker build -t djp-sound-ultimate .

# Lancer le conteneur
docker run -p 3000:3000 --env-file .env.production djp-sound-ultimate
```

---

## 🔒 Sécurité en production

### 1. Variables d'environnement
- ✅ Ne jamais commiter `.env.production` dans Git
- ✅ Utiliser les variables d'environnement de la plateforme
- ✅ Roter les clés API régulièrement

### 2. Headers de sécurité
- ✅ Déjà configurés dans `next.config.js` (CSP, HSTS, etc.)
- ✅ Vérifiez qu'ils sont actifs en production

### 3. Rate limiting
- ✅ Déjà configuré dans `middleware.ts`
- ✅ Pour plus de robustesse, utilisez Cloudflare ou un service dédié

### 4. HTTPS obligatoire
- ✅ Vercel/Netlify : HTTPS automatique
- ✅ VPS : Utilisez Let's Encrypt (gratuit)

---

## 📊 Monitoring et Analytics

### Options recommandées
- **Vercel Analytics** : Intégré avec Vercel
- **Google Analytics** : Pour le tracking
- **Sentry** : Pour le monitoring d'erreurs
- **Uptime Robot** : Pour surveiller la disponibilité

---

## ✅ Checklist de déploiement

### Avant le déploiement
- [ ] `npm run build` fonctionne sans erreur
- [ ] Toutes les variables d'environnement configurées
- [ ] Tests locaux réussis
- [ ] `.env.production` créé (ne pas le commiter)
- [ ] `.gitignore` contient `.env*`

### Configuration
- [ ] Variables d'environnement ajoutées sur la plateforme
- [ ] Domaine configuré (si applicable)
- [ ] HTTPS activé
- [ ] Headers de sécurité vérifiés

### Après le déploiement
- [ ] Site accessible
- [ ] Toutes les pages fonctionnent
- [ ] Connexion wallet fonctionne
- [ ] Upload fonctionne (si backend configuré)
- [ ] Compteur de visites fonctionne
- [ ] Bibliothèque fonctionne

### Performance
- [ ] Temps de chargement < 3 secondes
- [ ] Images optimisées
- [ ] CDN activé (si disponible)

---

## 🚨 Rollback (en cas de problème)

### Vercel
- Dashboard → Deployments → Cliquez sur un ancien déploiement → "Promote to Production"

### Netlify
- Dashboard → Deploys → Cliquez sur un ancien déploiement → "Publish deploy"

### VPS/PM2
```bash
pm2 restart djp-sound
# Ou restaurer depuis un backup
```

---

## 📞 Support

- **Documentation Next.js** : https://nextjs.org/docs/deployment
- **Documentation Vercel** : https://vercel.com/docs
- **Documentation Netlify** : https://docs.netlify.com

---

**Bon déploiement ! 🚀**

