import '../styles/globals.css';
import ErrorBoundary from '../components/ErrorBoundary';
import { useWebVitals } from '../hooks/useWebVitals';

export default function App({ Component, pageProps }) {
  // Track Web Vitals pour le monitoring de performance
  useWebVitals();

  return (
    <ErrorBoundary>
      <Component {...pageProps} />
    </ErrorBoundary>
  );
}

