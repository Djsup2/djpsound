#!/bin/bash
# Script de déploiement automatique pour Hostinger VPS
# Usage: ./deploy-hostinger.sh

set -e

echo "=========================================="
echo "Déploiement DJP Sound Ultimate sur Hostinger"
echo "=========================================="
echo ""

# Couleurs pour les messages
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Vérifier que nous sommes root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Erreur: Ce script doit être exécuté en tant que root${NC}"
    echo "Utilisez: sudo ./deploy-hostinger.sh"
    exit 1
fi

echo -e "${YELLOW}[1/8] Mise à jour du système...${NC}"
apt update && apt upgrade -y

echo -e "${YELLOW}[2/8] Installation de Node.js 18...${NC}"
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt install -y nodejs
else
    echo "Node.js est déjà installé: $(node --version)"
fi

echo -e "${YELLOW}[3/8] Installation de PM2...${NC}"
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
else
    echo "PM2 est déjà installé"
fi

echo -e "${YELLOW}[4/8] Installation de Nginx...${NC}"
if ! command -v nginx &> /dev/null; then
    apt install -y nginx
    systemctl enable nginx
else
    echo "Nginx est déjà installé"
fi

echo -e "${YELLOW}[5/8] Création de l'utilisateur nextjs...${NC}"
if ! id "nextjs" &>/dev/null; then
    adduser --disabled-password --gecos "" nextjs
    usermod -aG sudo nextjs
    echo "Utilisateur nextjs créé"
else
    echo "Utilisateur nextjs existe déjà"
fi

echo -e "${YELLOW}[6/8] Configuration du dossier de l'application...${NC}"
APP_DIR="/home/nextjs/djp-sound-ultimate"
mkdir -p $APP_DIR
chown -R nextjs:nextjs $APP_DIR

echo -e "${GREEN}✓ Configuration système terminée${NC}"
echo ""
echo -e "${YELLOW}Prochaines étapes manuelles:${NC}"
echo "1. Transférez vos fichiers dans: $APP_DIR"
echo "2. Connectez-vous en tant que nextjs: su - nextjs"
echo "3. Allez dans le dossier: cd ~/djp-sound-ultimate"
echo "4. Installez les dépendances: npm install --production"
echo "5. Créez .env.production avec vos variables"
echo "6. Builder: npm run build"
echo "7. Démarrez avec PM2: pm2 start npm --name 'djp-sound' -- start"
echo "8. Configurez Nginx (voir DEPLOIEMENT_HOSTINGER.md)"
echo ""
echo -e "${GREEN}Consultez DEPLOIEMENT_HOSTINGER.md pour les instructions complètes${NC}"

