# ✅ Checklist de vérification

## Avant de lancer le projet

- [ ] Node.js 18+ installé
- [ ] npm ou yarn installé
- [ ] Tous les fichiers présents dans le dossier

## Installation

- [ ] Exécuter `npm install`
- [ ] Vérifier qu'il n'y a pas d'erreurs
- [ ] (Optionnel) Créer `.env.local` depuis `.env.example`

## Fichiers essentiels vérifiés

- [x] `djp-sound-ultimate.jsx` (composant principal)
- [x] `package.json` (dépendances)
- [x] `pages/index.jsx` (point d'entrée)
- [x] `pages/_app.jsx` (app wrapper)
- [x] `next.config.js` (configuration Next.js)
- [x] `middleware.ts` (rate limiting)
- [x] `tailwind.config.js` (Tailwind CSS)
- [x] `postcss.config.js` (PostCSS)
- [x] `styles/globals.css` (styles globaux)
- [x] `pages/api/upload/sign.ts` (endpoint API)
- [x] `tsconfig.json` (TypeScript)
- [x] `.env.example` (template env)
- [x] `.gitignore` (git ignore)
- [x] `README.md` (documentation)
- [x] `SETUP.md` (guide démarrage)

## Démarrage

- [ ] Exécuter `npm run dev`
- [ ] Ouvrir http://localhost:3000
- [ ] Vérifier que la page d'accueil s'affiche
- [ ] Tester la navigation (Accueil, Upload, Bibliothèque, Paramètres)

## Tests fonctionnels

- [ ] Compteur de visites fonctionne
- [ ] Bibliothèque s'affiche (vide au début)
- [ ] Connexion wallet (MetaMask/Phantom) fonctionne
- [ ] Badge "Créateur" ou "Gestion" s'affiche si adresse correspond
- [ ] Accès Upload/Paramètres si wallet privilégié connecté

## Tests upload (si backend configuré)

- [ ] Upload de fichier fonctionne
- [ ] Barre de progression s'affiche
- [ ] Retry en cas d'erreur
- [ ] Annulation possible
- [ ] Fichier visible dans la bibliothèque après upload

## Production

- [ ] `npm run build` réussit sans erreur
- [ ] `npm start` lance le serveur
- [ ] Variables d'environnement configurées pour production
- [ ] Headers de sécurité actifs (CSP, etc.)

