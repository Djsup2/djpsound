# Guide de démarrage rapide

## 🚀 Installation en 3 étapes

### 1. Installer les dépendances
```bash
npm install
```

### 2. Configurer l'environnement (optionnel)
```bash
# Copier le fichier d'exemple
cp .env.example .env.local

# Éditer .env.local si vous voulez activer :
# - Upload persistant (S3 ou Supabase)
# - API Birdeye pour compteur de holders
# - RPC Ethereum fallback
```

### 3. Lancer le serveur de développement
```bash
npm run dev
```

Ouvrez [](http://localhost:3000) dans votre navigateur.

## ✅ Vérification

- ✅ Page d'accueil s'affiche
- ✅ Navigation fonctionne (Accueil, Upload, Bibliothèque, Paramètres)
- ✅ Compteur de visites fonctionne (localStorage)
- ✅ Bibliothèque vide au démarrage (normal)

## 🔐 Tester les fonctionnalités privilégiées

### Avec MetaMask (Gestionnaire)
1. Installez MetaMask
2. Connectez-vous avec l'adresse : `0x41e1f657a959cdbb09d803d59186dacab0a438ce`
3. Vous devriez voir le badge "Gestion" dans le wallet
4. Accès à Upload et Paramètres débloqué

### Avec Phantom (Créateur)
1. Installez Phantom
2. Connectez-vous avec l'adresse : `4wj3rnh3y318TR4HLV77Vdu76Ag4uwPJGNeYiTEv3Xd8`
3. Vous devriez voir le badge "Créateur" dans le wallet
4. Accès à Upload et Paramètres débloqué

## 📝 Notes importantes

- **Sans backend configuré** : Les uploads sont stockés localement (blob: URLs). Ils disparaissent au rechargement.
- **Avec S3/Supabase** : Les fichiers sont uploadés et les URLs persistantes sont sauvegardées.
- Les miniatures images sont toujours persistantes (Data URLs dans localStorage).

## 🐛 Problèmes courants

**Erreur "Module not found"**
```bash
rm -rf node_modules package-lock.json
npm install
```

**Erreur Tailwind CSS**
```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

**Port 3000 déjà utilisé**
```bash
# Utiliser un autre port
PORT=3001 npm run dev
```

## 📦 Build pour production

```bash
npm run build
npm start
```

