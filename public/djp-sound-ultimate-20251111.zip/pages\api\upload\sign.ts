import type { NextApiRequest, NextApiResponse } from 'next';

type SignResponse =
  | { uploadUrl: string; objectUrl: string; headers?: Record<string, string> }
  | { error: string };

// Helpers
function isAllowedMime(mime: string): boolean {
  const allow = [
    'audio/mpeg', // mp3
    'audio/wav',
    'audio/aac',
    'audio/mp4', // m4a
    'video/mp4',
    'image/jpeg',
    'image/png',
  ];
  return allow.includes(mime);
}

export default async function handler(req: NextApiRequest, res: NextApiResponse<SignResponse>) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }
  try {
    const { name, type, size } = req.body as { name?: string; type?: string; size?: number };
    if (!name || !type || !size) {
      return res.status(400).json({ error: 'Missing name/type/size' });
    }
    if (!isAllowedMime(type)) {
      return res.status(400).json({ error: 'MIME type not allowed' });
    }
    const maxSize = Number(process.env.UPLOAD_MAX_SIZE_BYTES || `${200 * 1024 * 1024}`); // 200MB default
    if (size > maxSize) {
      return res.status(400).json({ error: 'File too large' });
    }

    const backend = (process.env.UPLOAD_BACKEND || 's3').toLowerCase();
    const sanitizedName = name.replace(/[^a-zA-Z0-9._-]/g, '_');
    const ext = sanitizedName.includes('.') ? sanitizedName.split('.').pop() : undefined;
    const now = new Date();
    const key = `${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${Date.now()}-${Math.random()
      .toString(36)
      .slice(2)}${ext ? `.${ext}` : ''}`;

    if (backend === 's3') {
      const region = process.env.S3_REGION;
      const bucket = process.env.S3_BUCKET;
      const accessKeyId = process.env.S3_ACCESS_KEY;
      const secretAccessKey = process.env.S3_SECRET_KEY;
      if (!region || !bucket || !accessKeyId || !secretAccessKey) {
        return res.status(500).json({ error: 'S3 not configured' });
      }
      // Dynamic import to avoid hard dependency if not used
      const { S3Client, PutObjectCommand } = await import('@aws-sdk/client-s3');
      const { getSignedUrl } = await import('@aws-sdk/s3-request-presigner');

      const s3 = new S3Client({
        region,
        credentials: { accessKeyId, secretAccessKey },
      });
      const command = new PutObjectCommand({
        Bucket: bucket,
        Key: key,
        ContentType: type,
      });
      const uploadUrl = await getSignedUrl(s3, command, { expiresIn: 60 * 5 });
      const objectUrl = `https://${bucket}.s3.${region}.amazonaws.com/${key}`;
      return res.status(200).json({ uploadUrl, objectUrl, headers: { 'Content-Type': type } });
    }

    if (backend === 'supabase') {
      const supabaseUrl = process.env.SUPABASE_URL;
      const serviceKey = process.env.SUPABASE_SERVICE_ROLE;
      const bucket = process.env.SUPABASE_BUCKET || 'media';
      if (!supabaseUrl || !serviceKey) {
        return res.status(500).json({ error: 'Supabase not configured' });
      }
      // Using Storage signed upload URL (requires Supabase >= 2023-10 APIs)
      const filePath = key; // reuse same key format
      const createUrl = `${supabaseUrl}/storage/v1/bucket/${bucket}/upload/sign/${encodeURIComponent(filePath)}`;
      const resp = await fetch(createUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${serviceKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contentType: type,
          upsert: true,
        }),
      });
      if (!resp.ok) {
        const err = await resp.text();
        return res.status(500).json({ error: `Supabase sign failed: ${err}` });
      }
      const data = (await resp.json()) as { signedUrl: string };
      // Public object URL (if bucket is public) or use createSignedUrl to serve
      const objectUrl = `${supabaseUrl}/storage/v1/object/public/${bucket}/${filePath}`;
      return res.status(200).json({ uploadUrl: data.signedUrl, objectUrl, headers: { 'Content-Type': type } });
    }

    return res.status(400).json({ error: 'Unknown backend' });
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'Internal error' });
  }
}


