# ⚡ Déploiement rapide - 5 minutes

## 🎯 Option la plus simple : Vercel (Recommandé)

### Étape 1 : Préparer Git (2 min)

```bash
# Dans le dossier du projet
git init
git add .
git commit -m "Initial commit"
```

### Étape 2 : Créer un repo GitHub (1 min)

1. Allez sur https://github.com/new
2. Créez un nouveau repository (nom : `djp-sound-ultimate`)
3. Copiez l'URL du repo

### Étape 3 : Pousser le code (1 min)

```bash
git remote add origin https://github.com/VOTRE-USERNAME/djp-sound-ultimate.git
git branch -M main
git push -u origin main
```

### Étape 4 : Déployer sur Vercel (1 min)

1. Allez sur https://vercel.com/new
2. Connectez-vous avec GitHub
3. Importez votre repo `djp-sound-ultimate`
4. Vercel détecte automatiquement Next.js ✅
5. Cliquez sur **"Deploy"**

### Étape 5 : Configurer les variables (optionnel)

Si vous utilisez des APIs externes :

1. Dans Vercel → Votre projet → Settings → Environment Variables
2. Ajoutez vos variables :
   - `NEXT_PUBLIC_BIRDEYE_API_KEY` (si vous avez une clé)
   - `UPLOAD_BACKEND`, `S3_*`, etc. (si upload persistant)

✅ **C'est fait ! Votre site est en ligne sur : `votre-projet.vercel.app`**

---

## 🔄 Mises à jour futures

À chaque fois que vous poussez du code sur GitHub :

```bash
git add .
git commit -m "Mise à jour"
git push
```

Vercel déploie automatiquement ! 🚀

---

## 🌐 Ajouter un domaine personnalisé

1. Dans Vercel → Votre projet → Settings → Domains
2. Ajoutez votre domaine (ex: `monsite.com`)
3. Suivez les instructions DNS
4. HTTPS est automatique et gratuit ! 🔒

---

## 📊 Autres options rapides

### Netlify (alternative à Vercel)
1. https://www.netlify.com
2. "Add new site" → Import depuis GitHub
3. Build command : `npm run build`
4. Publish directory : `.next`
5. Deploy !

### Railway (avec Docker)
1. https://railway.app
2. New Project → Deploy from GitHub
3. Railway détecte le Dockerfile automatiquement
4. Ajoutez les variables d'environnement
5. Deploy !

---

**Besoin d'aide ? Consultez `DEPLOIEMENT.md` pour plus de détails.**

