# DJP Sound Ultimate

Plateforme révolutionnaire de gestion de contenus audio/visuels avec intégration Web3 (Ethereum & Solana), uploads persistants, et gestion de vitrines.

## 🚀 Démarrage rapide

### Prérequis

- Node.js 18+ et npm/yarn
- MetaMask (pour Ethereum) ou Phantom (pour Solana) - optionnel pour développement

### Installation

1. **Installer les dépendances**
   ```bash
   npm install
   # ou
   yarn install
   ```

2. **Configurer les variables d'environnement**
   ```bash
   cp .env.example .env.local
   ```
   Éditez `.env.local` et remplissez les variables nécessaires (voir section Configuration ci-dessous).

3. **Lancer le serveur de développement**
   ```bash
   npm run dev
   # ou
   yarn dev
   ```

4. **Ouvrir dans le navigateur**
   - Accédez à [http://localhost:3000](http://localhost:3000)

## 📋 Configuration

### Variables d'environnement minimales

Pour un fonctionnement de base (sans upload persistant), aucune variable n'est requise. Le site fonctionnera avec `localStorage` uniquement.

### Variables optionnelles

- `NEXT_PUBLIC_ETH_RPC` : RPC Ethereum (fallback si MetaMask absent)
- `NEXT_PUBLIC_BIRDEYE_API_KEY` : API Birdeye pour compteur de holders Solana

### Upload persistant (optionnel)

Pour activer les uploads vers S3 ou Supabase :

#### Option 1 : AWS S3
```env
UPLOAD_BACKEND=s3
S3_REGION=us-east-1
S3_BUCKET=mon-bucket
S3_ACCESS_KEY=AKIA...
S3_SECRET_KEY=...
```

#### Option 2 : Supabase Storage
```env
UPLOAD_BACKEND=supabase
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_SERVICE_ROLE=eyJ...
SUPABASE_BUCKET=media
```

## 🏗️ Structure du projet

```
.
├── djp-sound-ultimate.jsx    # Composant principal (pages/index.jsx)
├── pages/
│   └── api/
│       └── upload/
│           └── sign.ts       # Endpoint d'upload signé
├── next.config.js            # Configuration Next.js (CSP, headers)
├── middleware.ts             # Rate limiting API
├── package.json
├── .env.example
└── README.md
```

## 🔐 Accès privilégiés

- **Créateur Solana** : `4wj3rnh3y318TR4HLV77Vdu76Ag4uwPJGNeYiTEv3Xd8`
- **Gestionnaire Ethereum** : `0x41e1f657a959cdbb09d803d59186dacab0a438ce`

Ces adresses ont accès aux pages **Upload** et **Paramètres**.

## 🧪 Tests locaux

1. **Tester sans wallet**
   - Accédez à la page d'accueil et à la bibliothèque (lecture seule)

2. **Tester avec MetaMask**
   - Installez MetaMask
   - Connectez-vous avec l'adresse gestionnaire pour accéder à Upload/Paramètres

3. **Tester avec Phantom**
   - Installez Phantom
   - Connectez-vous avec l'adresse créateur pour accéder à Upload/Paramètres

4. **Tester les uploads**
   - Sans backend configuré : les fichiers sont stockés localement (blob: URLs)
   - Avec S3/Supabase : les fichiers sont uploadés et les URLs persistantes sont sauvegardées

## 📦 Build pour production

```bash
npm run build
npm start
```

## 🔒 Sécurité

- CSP (Content Security Policy) activée
- Rate limiting sur les routes `/api/*` (60 req/min par IP)
- Validation MIME et taille des fichiers côté serveur
- Limite de 50 éléments par vitrine (localStorage)

## 📝 Notes

- Les `blob:` URLs ne survivent pas au rechargement de page
- Les miniatures images sont persistantes (Data URLs dans localStorage)
- Pour des aperçus audio/vidéo persistants, configurez S3 ou Supabase

## 🐛 Dépannage

- **Erreur "Module not found"** : Exécutez `npm install`
- **Erreur de connexion wallet** : Vérifiez que MetaMask/Phantom est installé et déverrouillé
- **Upload échoue** : Vérifiez les variables d'environnement S3/Supabase dans `.env.local`

## 📄 Licence

Propriétaire - Tous droits réservés

