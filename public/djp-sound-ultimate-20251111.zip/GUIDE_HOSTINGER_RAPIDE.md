# ⚡ Déploiement rapide sur Hostinger VPS

## 🎯 En 10 étapes simples

### 1. Commander un VPS Hostinger
- Minimum : 2 vCPU, 2GB RAM
- OS : Ubuntu 20.04 ou 22.04

### 2. Se connecter au serveur
```bash
ssh root@VOTRE_IP_HOSTINGER
```

### 3. Exécuter le script d'installation
```bash
# Télécharger le script (ou le créer manuellement)
chmod +x deploy-hostinger.sh
sudo ./deploy-hostinger.sh
```

### 4. Transférer vos fichiers
**Option A : Via Git (recommandé)**
```bash
su - nextjs
cd ~/djp-sound-ultimate
git clone https://github.com/VOTRE-USERNAME/djp-sound-ultimate.git .
```

**Option B : Via SFTP**
- Utilisez FileZilla ou WinSCP
- Connectez-vous avec SFTP
- Transférez tous les fichiers dans `/home/nextjs/djp-sound-ultimate`

### 5. Installer les dépendances
```bash
cd ~/djp-sound-ultimate
npm install --production
```

### 6. Configurer les variables d'environnement
```bash
nano .env.production
# Collez vos variables (voir .env.production.example)
# Ctrl+X, Y, Enter pour sauvegarder
```

### 7. Builder l'application
```bash
npm run build
```

### 8. Démarrer avec PM2
```bash
pm2 start npm --name "djp-sound" -- start
pm2 save
pm2 startup
# Suivez les instructions affichées
```

### 9. Configurer Nginx
```bash
# Revenir en root
exit

# Copier la configuration
cp nginx-hostinger.conf /etc/nginx/sites-available/djp-sound

# Éditer et remplacer VOTRE_DOMAINE.com
nano /etc/nginx/sites-available/djp-sound

# Activer le site
ln -s /etc/nginx/sites-available/djp-sound /etc/nginx/sites-enabled/

# Tester et redémarrer
nginx -t
systemctl restart nginx
```

### 10. Configurer le domaine et SSL
```bash
# Dans Hostinger : Point DNS A vers l'IP du VPS
# Attendre quelques minutes pour la propagation

# Installer Certbot
apt install -y certbot python3-certbot-nginx

# Obtenir le certificat SSL
certbot --nginx -d VOTRE_DOMAINE.com -d www.VOTRE_DOMAINE.com
```

✅ **C'est fait ! Votre site est en ligne sur https://VOTRE_DOMAINE.com**

---

## 🔄 Mise à jour de l'application

```bash
ssh root@VOTRE_IP
su - nextjs
cd ~/djp-sound-ultimate
git pull
npm install --production
npm run build
pm2 restart djp-sound
```

---

## 📊 Commandes utiles

```bash
# Voir les logs
pm2 logs djp-sound

# Redémarrer
pm2 restart djp-sound

# Statut
pm2 status

# Arrêter
pm2 stop djp-sound
```

---

## 🐛 Problèmes courants

**L'application ne démarre pas**
```bash
pm2 logs djp-sound
# Vérifiez les erreurs dans les logs
```

**Nginx ne fonctionne pas**
```bash
nginx -t
tail -f /var/log/nginx/error.log
```

**Le domaine ne fonctionne pas**
- Vérifiez les DNS dans Hostinger
- Utilisez https://dnschecker.org
- Attendez 24-48h pour la propagation

---

**Besoin d'aide ? Consultez `DEPLOIEMENT_HOSTINGER.md` pour le guide complet.**

