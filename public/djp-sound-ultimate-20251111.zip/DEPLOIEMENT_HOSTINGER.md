# 🚀 Déploiement sur Hostinger

## 📋 Options Hostinger

Hostinger propose plusieurs types d'hébergement. Pour Next.js, vous avez 2 options principales :

### Option 1 : VPS Hostinger (Recommandé)
- ✅ Contrôle total
- ✅ Node.js supporté
- ✅ Performance optimale
- ⚠️ Nécessite des connaissances techniques

### Option 2 : Cloud Hosting Hostinger
- ✅ Interface simplifiée
- ⚠️ Peut nécessiter une configuration spéciale pour Node.js

## 🎯 Option 1 : VPS Hostinger (Recommandé)

### Étape 1 : Commander un VPS Hostinger

1. **Connectez-vous à votre compte Hostinger**
   - https://www.hostinger.com
   - Allez dans "VPS"

2. **Choisissez un plan VPS**
   - Minimum recommandé : 2 vCPU, 2GB RAM
   - OS : Ubuntu 20.04 ou 22.04 LTS

3. **Notez vos identifiants**
   - Adresse IP du serveur
   - Utilisateur root
   - Mot de passe root (ou clé SSH)

### Étape 2 : Se connecter au serveur

**Via SSH (Windows PowerShell ou PuTTY)** :

```bash
ssh root@VOTRE_IP_SERVEUR
```

Remplacez `VOTRE_IP_SERVEUR` par l'IP fournie par Hostinger.

### Étape 3 : Installer Node.js et dépendances

```bash
# Mettre à jour le système
apt update && apt upgrade -y

# Installer Node.js 18 (LTS)
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs

# Vérifier l'installation
node --version
npm --version

# Installer PM2 (gestionnaire de processus)
npm install -g pm2

# Installer Nginx (reverse proxy)
apt install -y nginx
```

### Étape 4 : Préparer le projet

```bash
# Créer un utilisateur pour l'application (recommandé)
adduser --disabled-password --gecos "" nextjs
usermod -aG sudo nextjs

# Passer à l'utilisateur nextjs
su - nextjs

# Créer le dossier de l'application
mkdir -p ~/djp-sound-ultimate
cd ~/djp-sound-ultimate
```

### Étape 5 : Transférer les fichiers

**Option A : Via Git (Recommandé)**

```bash
# Installer Git
apt install -y git

# Cloner votre repository
git clone https://github.com/VOTRE-USERNAME/djp-sound-ultimate.git .
```

**Option B : Via FTP/SFTP**

1. Utilisez FileZilla ou WinSCP
2. Connectez-vous avec :
   - Host : VOTRE_IP_SERVEUR
   - Utilisateur : root (ou nextjs)
   - Port : 22 (SSH)
   - Protocole : SFTP
3. Transférez tous les fichiers du projet

### Étape 6 : Installer les dépendances et builder

```bash
# Dans le dossier du projet
npm install --production

# Créer le fichier .env.production
nano .env.production
# Collez vos variables d'environnement
# Ctrl+X pour sauvegarder, puis Y, puis Enter

# Builder l'application
npm run build
```

### Étape 7 : Démarrer avec PM2

```bash
# Démarrer l'application
pm2 start npm --name "djp-sound" -- start

# Sauvegarder la configuration PM2
pm2 save

# Configurer PM2 pour démarrer au boot
pm2 startup
# Suivez les instructions affichées
```

### Étape 8 : Configurer Nginx (Reverse Proxy)

```bash
# Revenir en root
exit

# Créer la configuration Nginx
nano /etc/nginx/sites-available/djp-sound
```

Collez cette configuration :

```nginx
server {
    listen 80;
    server_name VOTRE_DOMAINE.com www.VOTRE_DOMAINE.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Remplacez `VOTRE_DOMAINE.com` par votre domaine.

```bash
# Activer le site
ln -s /etc/nginx/sites-available/djp-sound /etc/nginx/sites-enabled/

# Tester la configuration
nginx -t

# Redémarrer Nginx
systemctl restart nginx
```

### Étape 9 : Configurer le domaine dans Hostinger

1. **Allez dans le panneau Hostinger**
2. **Domaines** → Votre domaine
3. **DNS** → Ajoutez un enregistrement A :
   - Type : A
   - Nom : @ (ou laissez vide)
   - Valeur : IP de votre VPS
   - TTL : 3600

4. **Pour www** :
   - Type : A
   - Nom : www
   - Valeur : IP de votre VPS

### Étape 10 : Activer HTTPS (Let's Encrypt)

```bash
# Installer Certbot
apt install -y certbot python3-certbot-nginx

# Obtenir le certificat SSL
certbot --nginx -d VOTRE_DOMAINE.com -d www.VOTRE_DOMAINE.com

# Suivez les instructions
# Certbot configurera automatiquement Nginx pour HTTPS
```

### Étape 11 : Vérifier que tout fonctionne

1. Visitez `http://VOTRE_DOMAINE.com`
2. Vous devriez être redirigé vers HTTPS automatiquement
3. Vérifiez que le site fonctionne

---

## 🎯 Option 2 : Cloud Hosting Hostinger (Alternative)

Si vous avez un Cloud Hosting Hostinger, vous pouvez essayer cette méthode :

### Méthode : Utiliser Node.js via cPanel (si disponible)

1. **Connectez-vous à cPanel Hostinger**
2. **Cherchez "Node.js Selector" ou "Setup Node.js App"**
3. **Créez une nouvelle application Node.js** :
   - Node.js version : 18.x
   - Application root : `/home/username/djp-sound-ultimate`
   - Application URL : `/`
   - Application startup file : `server.js`

4. **Dans le terminal cPanel ou via SSH** :
   ```bash
   cd ~/djp-sound-ultimate
   npm install --production
   npm run build
   ```

5. **Configurez les variables d'environnement** dans l'interface Node.js Selector

6. **Démarrez l'application** depuis l'interface

⚠️ **Note** : Cette méthode peut ne pas être disponible sur tous les plans Hostinger. Vérifiez avec le support Hostinger.

---

## 🔧 Configuration avancée

### Mise à jour de l'application

```bash
# Se connecter au serveur
ssh root@VOTRE_IP

# Passer à l'utilisateur nextjs
su - nextjs
cd ~/djp-sound-ultimate

# Récupérer les dernières modifications
git pull

# Réinstaller les dépendances si nécessaire
npm install --production

# Rebuilder
npm run build

# Redémarrer avec PM2
pm2 restart djp-sound
```

### Voir les logs

```bash
# Logs de l'application
pm2 logs djp-sound

# Logs Nginx
tail -f /var/log/nginx/error.log
tail -f /var/log/nginx/access.log
```

### Redémarrer l'application

```bash
pm2 restart djp-sound
```

### Arrêter l'application

```bash
pm2 stop djp-sound
```

---

## 🔒 Sécurité

### Firewall (UFW)

```bash
# Installer UFW
apt install -y ufw

# Autoriser SSH
ufw allow 22/tcp

# Autoriser HTTP et HTTPS
ufw allow 80/tcp
ufw allow 443/tcp

# Activer le firewall
ufw enable
```

### Mise à jour automatique

```bash
# Installer unattended-upgrades
apt install -y unattended-upgrades

# Configurer
dpkg-reconfigure -plow unattended-upgrades
```

---

## 📊 Monitoring

### PM2 Monitoring

```bash
# Interface web PM2 (optionnel)
pm2 web

# Statut
pm2 status

# Informations détaillées
pm2 show djp-sound
```

### Ressources système

```bash
# Utilisation CPU/RAM
htop

# Espace disque
df -h
```

---

## 🐛 Dépannage

### L'application ne démarre pas

```bash
# Vérifier les logs
pm2 logs djp-sound

# Vérifier que le port 3000 est libre
netstat -tulpn | grep 3000

# Vérifier les variables d'environnement
pm2 env djp-sound
```

### Nginx ne fonctionne pas

```bash
# Vérifier la configuration
nginx -t

# Vérifier les logs
tail -f /var/log/nginx/error.log

# Redémarrer Nginx
systemctl restart nginx
```

### Le domaine ne pointe pas vers le site

1. Vérifiez les DNS dans Hostinger
2. Utilisez https://dnschecker.org pour vérifier la propagation
3. Attendez 24-48h pour la propagation complète

---

## ✅ Checklist de déploiement Hostinger

- [ ] VPS Hostinger commandé
- [ ] Node.js 18+ installé
- [ ] PM2 installé
- [ ] Nginx installé et configuré
- [ ] Fichiers du projet transférés
- [ ] Dépendances installées (`npm install`)
- [ ] Build réussi (`npm run build`)
- [ ] Variables d'environnement configurées
- [ ] Application démarrée avec PM2
- [ ] Nginx configuré comme reverse proxy
- [ ] Domaine pointé vers le VPS
- [ ] HTTPS activé (Let's Encrypt)
- [ ] Firewall configuré
- [ ] Site accessible et fonctionnel

---

## 📞 Support Hostinger

Si vous rencontrez des problèmes :
- **Support Hostinger** : https://www.hostinger.com/contact
- **Documentation Hostinger** : https://support.hostinger.com/
- **Chat en direct** : Disponible dans le panneau Hostinger

---

**Votre site Next.js est maintenant déployé sur Hostinger ! 🎉**

