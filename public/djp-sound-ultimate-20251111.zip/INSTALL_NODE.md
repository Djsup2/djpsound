# 📦 Guide d'installation de Node.js

## 🎯 Méthode 1 : Installation manuelle (Recommandée)

### Étape 1 : Télécharger Node.js

1. **Allez sur le site officiel** : https://nodejs.org/
2. **Téléchargez la version LTS** (Long Term Support)
   - Cliquez sur le bouton vert "LTS" (recommandé)
   - Version actuelle : Node.js 20.x ou 18.x
3. **Choisissez la version Windows** :
   - `.msi` pour Windows (installateur automatique)
   - Téléchargez le fichier `.msi`

### Étape 2 : Installer Node.js

1. **Double-cliquez sur le fichier téléchargé** (ex: `node-v20.x.x-x64.msi`)
2. **Suivez l'assistant d'installation** :
   - ✅ Cliquez sur "Next" plusieurs fois
   - ✅ **IMPORTANT** : Cochez "Add to PATH" si proposé
   - ✅ Acceptez les termes et conditions
   - ✅ Cliquez sur "Install"
3. **Attendez la fin de l'installation** (1-2 minutes)
4. **Cliquez sur "Finish"**

### Étape 3 : Vérifier l'installation

1. **Ouvrez PowerShell** (Windows + X → Windows PowerShell)
2. **Tapez ces commandes** :
   ```powershell
   node --version
   npm --version
   ```
3. **Vous devriez voir** :
   ```
   v20.x.x
   10.x.x
   ```
   (Les numéros peuvent varier selon la version)

✅ **Si vous voyez des versions, Node.js est installé !**

## 🎯 Méthode 2 : Installation via Chocolatey (Optionnel)

Si vous avez Chocolatey installé :

```powershell
choco install nodejs-lts
```

## 🎯 Méthode 3 : Installation via Winget (Windows 10/11)

```powershell
winget install OpenJS.NodeJS.LTS
```

## ✅ Après l'installation

### 1. Redémarrer le terminal

**IMPORTANT** : Fermez et rouvrez PowerShell/CMD après l'installation pour que les changements prennent effet.

### 2. Vérifier que tout fonctionne

```powershell
node --version
npm --version
```

### 3. Installer les dépendances du projet

```powershell
cd "C:\Users\iedje\OneDrive\Desktop\Nouveau dossier (2)"
npm install
```

### 4. Lancer le serveur

```powershell
npm run dev
```

## 🐛 Problèmes courants

### "node n'est pas reconnu"
- **Solution 1** : Redémarrez votre terminal/PowerShell
- **Solution 2** : Vérifiez que "Add to PATH" était coché pendant l'installation
- **Solution 3** : Réinstallez Node.js en cochant "Add to PATH"

### "npm n'est pas reconnu"
- npm est inclus avec Node.js
- Si node fonctionne mais pas npm, réinstallez Node.js

### Erreur de permissions
- Exécutez PowerShell en tant qu'administrateur (clic droit → "Exécuter en tant qu'administrateur")

## 📋 Checklist

- [ ] Node.js téléchargé depuis nodejs.org
- [ ] Node.js installé avec "Add to PATH" coché
- [ ] Terminal redémarré
- [ ] `node --version` fonctionne
- [ ] `npm --version` fonctionne
- [ ] Dépendances installées (`npm install`)
- [ ] Serveur lancé (`npm run dev`)

## 🔗 Liens utiles

- **Site officiel Node.js** : https://nodejs.org/
- **Documentation npm** : https://docs.npmjs.com/
- **Guide Next.js** : https://nextjs.org/docs

---

**Une fois Node.js installé, suivez les instructions dans `DEMARRAGE.md` pour lancer votre site !**

