# 🚀 Guide de démarrage - Visualiser votre site

## Option 1 : Aperçu rapide (HTML statique)

1. **Ouvrez le fichier `preview.html`** dans votre navigateur
   - Double-cliquez sur `preview.html`
   - Ou faites clic droit → "Ouvrir avec" → Chrome/Firefox/Edge

   ⚠️ **Note** : C'est un aperçu statique. Pour voir le site complet avec toutes les fonctionnalités, utilisez l'Option 2.

## Option 2 : Site complet (Next.js - Recommandé)

### Étape 1 : Installer Node.js

1. Téléchargez Node.js 18+ depuis : **https://nodejs.org/**
2. Installez-le (cochez "Add to PATH" pendant l'installation)
3. Redémarrez votre terminal/PowerShell

### Étape 2 : Vérifier l'installation

Ouvrez PowerShell ou CMD et tapez :
```bash
node --version
npm --version
```

Vous devriez voir des numéros de version (ex: v18.17.0 et 9.6.7)

### Étape 3 : Installer les dépendances

Dans PowerShell, naviguez vers le dossier :
```powershell
cd "C:\Users\iedje\OneDrive\Desktop\Nouveau dossier (2)"
```

Puis installez les dépendances :
```bash
npm install
```

⏱️ **Cela peut prendre 2-5 minutes** la première fois.

### Étape 4 : Lancer le serveur

```bash
npm run dev
```

Vous devriez voir :
```
  ▲ Next.js 14.x.x
  - Local:        http://localhost:3000
  - ready started server on 0.0.0.0:3000
```

### Étape 5 : Ouvrir dans le navigateur

1. Ouvrez votre navigateur (Chrome, Firefox, Edge)
2. Allez à : **http://localhost:3000**
3. Votre site devrait s'afficher ! 🎉

## 🎯 Fonctionnalités à tester

- ✅ **Page d'accueil** : Affichage avec 3 cartes (Bibliothèque, Upload, Web3)
- ✅ **Navigation** : Cliquez sur les onglets (Accueil, Upload, Bibliothèque, Paramètres)
- ✅ **Compteur de visites** : Visible en haut à droite
- ✅ **Bibliothèque** : Vide au début, se remplit après uploads
- ✅ **Connexion wallet** : Boutons Ethereum/Solana en haut à droite

## 🔐 Tester les fonctionnalités privilégiées

### Avec MetaMask (Gestionnaire)
1. Installez l'extension MetaMask
2. Connectez-vous avec : `0x41e1f657a959cdbb09d803d59186dacab0a438ce`
3. Le badge "Gestion" apparaît
4. Accès à Upload et Paramètres débloqué

### Avec Phantom (Créateur)
1. Installez l'extension Phantom
2. Connectez-vous avec : `4wj3rnh3y318TR4HLV77Vdu76Ag4uwPJGNeYiTEv3Xd8`
3. Le badge "Créateur" apparaît
4. Accès à Upload et Paramètres débloqué

## 🐛 Problèmes courants

### "npm n'est pas reconnu"
- **Solution** : Installez Node.js depuis nodejs.org et redémarrez le terminal

### "Port 3000 déjà utilisé"
- **Solution** : Fermez l'autre application ou utilisez un autre port :
  ```bash
  PORT=3001 npm run dev
  ```

### "Module not found"
- **Solution** : Réinstallez les dépendances :
  ```bash
  rm -r node_modules
  npm install
  ```

### Erreurs de compilation
- Vérifiez que tous les fichiers sont présents
- Vérifiez `package.json` pour les dépendances

## 📞 Support

Si vous rencontrez des problèmes :
1. Vérifiez que Node.js 18+ est installé
2. Vérifiez que vous êtes dans le bon dossier
3. Vérifiez les messages d'erreur dans le terminal
4. Consultez `README.md` pour plus de détails

---

**Bon développement ! 🚀**

