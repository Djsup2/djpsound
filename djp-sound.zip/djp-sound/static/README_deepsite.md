# Instructions pour Deepsite

1. Connecte-toi à Deepsite et crée un nouveau site.
2. Choisis 'Code HTML personnalisé'.
3. Ouvre `static/index.html` et colle le contenu dans l'éditeur.
4. Si tu veux le chat IA, crée un endpoint serveur (par ex. Vercel) et remplace l'URL `https://tonserveur.vercel.app/api/chat` par ton endpoint.
