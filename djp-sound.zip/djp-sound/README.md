# DJP Sound — Projet prêt à déployer

Ce dépôt contient **2 versions** prêtes à l'emploi :

1. **Next.js (app router)** — backend + frontend + API pour OpenAI. (déployable sur Vercel)
2. **Static HTML** (index.html) — version prête à coller sur Deepsite.

---

## Configuration (Next.js)
- Copier `.env.production.sample` -> `.env.production` et remplir `OPENAI_API_KEY`.
- Installer dépendances : `npm ci`.
- Build : `npm run build`.
- Déploiement : utiliser `deploy.sh` ou déployer sur Vercel/Netlify.

## Déploiement sur Deepsite (static)
- Ouvrir Deepsite, créer un site en `Code HTML personnalisé` et coller le contenu de `static/index.html`.

---

## Contenu du bundle
- `nextjs/` : projet Next.js minimal (app router), endpoints `/api/chat` et `/api/health`.
- `static/` : version HTML/CSS/JS prête pour Deepsite.
- `deploy.sh` : script pour cloner et déployer (exemple) sur Vercel.

---

Bonne chance — dis-moi si tu veux que je customise le style, le texte, ou que je crée le dépôt GitHub automatiquement.
