export default function Header(){ 
  return (
    <header style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
      <h1>🎧 DJP Sound</h1>
      <nav>
        <a href="#" style={{marginRight:12}}>Mix</a>
        <a href="#" style={{marginRight:12}}>Chat IA</a>
        <a href="#">Contact</a>
      </nav>
    </header>
  )
}
