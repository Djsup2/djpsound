'use client'
import {useState, useRef, useEffect} from 'react'

export default function ChatUI(){
  const [messages,setMessages]=useState([])
  const [input,setInput]=useState('')
  const listRef = useRef(null)

  useEffect(()=>{ if(listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight },[messages])

  async function sendMessage(){
    if(!input.trim()) return
    const user = { role:'user', content: input }
    const next = [...messages, user]
    setMessages(next)
    setInput('')

    try {
      const res = await fetch('/api/chat', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ messages: next })
      })
      const data = await res.json()
      setMessages(prev=>[...prev, { role:'assistant', content: data.reply || '...' }])
    } catch(e){
      setMessages(prev=>[...prev, { role:'assistant', content: 'Erreur de connexion à l\'IA.' }])
    }
  }

  return (
    <div style={{maxWidth:900, margin:'20px auto'}} className="card">
      <div ref={listRef} style={{height:320,overflow:'auto',padding:8,background:'#0a0a0a',borderRadius:8}}>
        {messages.map((m,i)=>(
          <div key={i} style={{textAlign: m.role==='user'?'right':'left', margin:'8px 0'}}>
            <div style={{display:'inline-block',padding:10,borderRadius:8, background: m.role==='user'?'#0b63ff':'#222'}}>
              {m.content}
            </div>
          </div>
        ))}
      </div>
      <div style={{display:'flex',gap:8,marginTop:8}}>
        <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendMessage()} placeholder="Écris à DJP Sound..." style={{flex:1,padding:8,borderRadius:8,border:'none',background:'#111'}} />
        <button onClick={sendMessage} style={{background:'#ff0050',color:'#fff',padding:'8px 14px',borderRadius:8}}>Envoyer</button>
      </div>
    </div>
  )
}
