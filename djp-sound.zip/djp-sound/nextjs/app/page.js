import dynamic from 'next/dynamic'
import Header from './components/Header'

const ChatUI = dynamic(() => import('./components/ChatUI'), { ssr:false })

export default function Home() {
  return (
    <main className="container">
      <Header />
      <section style={{marginTop:20}}>
        <div className="card">
          <h2>DJP Sound — Vibes & Intelligence</h2>
          <p>Bienvenue — parle à l'assistant pour demander des playlists, idées de set, ou conseils techniques.</p>
        </div>
      </section>
      <section style={{marginTop:20}}>
        <ChatUI />
      </section>
    </main>
  )
}
