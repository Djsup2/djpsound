import OpenAI from 'openai'

export async function POST(req){
  try{
    const body = await req.json()
    const messages = body.messages || [{ role: 'user', content: 'Hello' }]

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

    // Utilise Chat Completions (interface de démonstration)
    const completion = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: messages.map(m=>({ role: m.role, content: m.content }))
    })

    const reply = completion.choices?.[0]?.message?.content || 'Désolé, pas de réponse.'
    return new Response(JSON.stringify({ reply }), { status:200, headers: { 'Content-Type': 'application/json' } })
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message || String(err) }), { status:500 })
  }
}
